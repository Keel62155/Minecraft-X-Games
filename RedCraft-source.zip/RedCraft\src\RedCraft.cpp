// RedCraft: Minecraft inside Red Dead Redemption 2.
//
// An ASI plugin for Script Hook RDR2 that plays the part SkyCraft's Skyrim plugin plays: the stock
// SkyCraft Minecraft runs hidden next to the game and the two talk over shared memory. The game
// supplies the shape of the world; Minecraft supplies where the player is and its picture.
//
// Unlike the Hitman and Cyberpunk ports, this one owns the camera (a script camera at the Minecraft
// player's eyes), hides the game's own character and blocks the game's controls outright, which is
// how SkyCraft itself works.

#include "Collision.h"
#include "Game.h"
#include "Link.h"
#include "Log.h"
#include "Renderer.h"

#include "../vendor/ScriptHookRDR2_SDK/inc/main.h"
#include "../vendor/ScriptHookRDR2_SDK/inc/nativeCaller.h"
#include "../vendor/ScriptHookRDR2_SDK/inc/types.h"

#include <shellapi.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

namespace {
using Vec3 = HitCraftCollision::Vec3;
using namespace hitcraft::proto;

// ---------------------------------------------------------------------------------------------
// The game's script functions used here (hashes from the SDK's natives.h).
// ---------------------------------------------------------------------------------------------
namespace N {
Ped PlayerPed() { return invoke<Ped>(0x096275889B8E0EE0); }
Player PlayerId() { return invoke<Player>(0x217E9DC48139933D); }
bool IsPlayerPlaying(Player p) { return invoke<BOOL>(0xBFFB35986CAAE58C, p) != 0; }
bool IsPlayerControlOn(Player p) { return invoke<BOOL>(0x7964097FCE4C244B, p) != 0; }
bool DoesEntityExist(Entity e) { return invoke<BOOL>(0xD42BD6EB2E0F1677, e) != 0; }
Vector3 GetEntityCoords(Entity e) { return invoke<Vector3>(0xA86D5F069399F44D, e, TRUE, TRUE); }
void SetEntityCoordsNoOffset(Entity e, float x, float y, float z) { invoke<Void>(0x239A3351AC1DA385, e, x, y, z, FALSE, FALSE, FALSE); }
void SetEntityHeading(Entity e, float heading) { invoke<Void>(0xCF2B9C0645C4651B, e, heading); }
void SetEntityVelocity(Entity e, float x, float y, float z) { invoke<Void>(0x1C99BB7B6E96D16F, e, x, y, z); }
void FreezeEntityPosition(Entity e, bool toggle) { invoke<Void>(0x7D9EFB7AD6B19754, e, toggle ? TRUE : FALSE); }
void SetEntityVisible(Entity e, bool toggle) { invoke<Void>(0x1794B4FCC84D812F, e, toggle ? TRUE : FALSE); }
void SetEntityInvincible(Entity e, bool toggle) { invoke<Void>(0xA5C38736C426FCB8, e, toggle ? TRUE : FALSE); }
bool IsEntityDead(Entity e) { return invoke<BOOL>(0x7D5B1F88E7504BBA, e) != 0; }
int GetEntityHealth(Entity e) { return invoke<int>(0x82368787EA73C0F7, e); }
int GetEntityMaxHealth(Entity e) { return invoke<int>(0x15D757606D170C3C, e, FALSE); }
void SetEntityHealth(Entity e, int health, Entity by) { invoke<Void>(0xAC2767ED8BDFAB15, e, health, by); }
bool IsPedOnMount(Ped p) { return invoke<BOOL>(0x460BC76A0E10655E, p) != 0; }
bool IsPedInAnyVehicle(Ped p) { return invoke<BOOL>(0x997ABD671D25CA0B, p, FALSE) != 0; }
bool IsPauseMenuActive() { return invoke<BOOL>(0x535384D6067BA42E) != 0; }
void DisableAllControlActions(int group) { invoke<Void>(0x5F4B6931816E599B, group); }
void EnableControlAction(int group, int control) { invoke<Void>(0x351220255D64C155, group, control, TRUE); }
void StartEntityFire(Entity e) { invoke<Void>(0xC4DC7418A44D6822, e, 1.0f, 0, 0); }
void AddExplosion(float x, float y, float z, int type, float damageScale) { invoke<Void>(0x7D6F58F69DA92530, x, y, z, type, damageScale, TRUE, FALSE, 1.0f); }
int StartShapeTestRay(float x1, float y1, float z1, float x2, float y2, float z2, int flags, Entity ignore) {
    return invoke<int>(0x377906D8A31E5586, x1, y1, z1, x2, y2, z2, flags, ignore, 7);
}
int GetShapeTestResult(int handle, BOOL* hit, Vector3* end, Vector3* normal, Entity* entity) {
    return invoke<int>(0xEDE8AC7C5108FB1D, handle, hit, end, normal, entity);
}
Cam CreateCam(const char* name) { return invoke<Cam>(0xE72CDBA7F0A02DD6, name, TRUE); }
void DestroyCam(Cam cam) { invoke<Void>(0x4E67E0B6D7FD5145, cam, FALSE); }
void SetCamActive(Cam cam, bool active) { invoke<Void>(0x87295BCA613800C8, cam, active ? TRUE : FALSE); }
void SetCamCoord(Cam cam, float x, float y, float z) { invoke<Void>(0xF9EE7D419EE49DE6, cam, x, y, z); }
void SetCamRot(Cam cam, float pitch, float roll, float yaw) { invoke<Void>(0x63DFA6810AD78719, cam, pitch, roll, yaw, 2); }
void SetCamFov(Cam cam, float fov) { invoke<Void>(0x27666E5988D9D429, cam, fov); }
void SetCamNearClip(Cam cam, float nearClip) { invoke<Void>(0xA924028272A61364, cam, nearClip); }
void RenderScriptCams(bool render) { invoke<Void>(0x33281167E4942E4F, render ? TRUE : FALSE, FALSE, 0, TRUE, TRUE, 0); }
Vector3 GetGameplayCamRot() { return invoke<Vector3>(0x0252D2B5582957A6, 2); }
void SetPedToRagdoll(Ped p, int minMs, int maxMs) { invoke<BOOL>(0xAE99FB955581844A, p, minMs, maxMs, 0, FALSE, FALSE, FALSE); }
}

constexpr float kRadiansToDegrees = 57.2957795f;
constexpr float kDegreesToRadians = 1.f / kRadiansToDegrees;
constexpr int kToggleDriveKey = VK_F10;
constexpr std::uint32_t kHitFire = 1u << 3;
// Shape test flags: 1 the map, 2 vehicles, 16 objects.
constexpr int kRayWorld = 1;
constexpr int kRayMoving = 2 | 16;

HitCraftLink g_Link;
HitCraftCollision g_Collision;

Ped g_Ped = 0;
bool g_DriveWanted = true;
bool g_DriveWasWanted = false;
bool g_Driving = false;
bool g_LaunchAttempted = false;
bool g_HadPlayer = false;
bool g_MinecraftWasAlive = false;
bool g_MinecraftWasInWorld = false;
bool g_NeedTeleport = false;
bool g_ToggleKeyDown = false;
bool g_WasForwardingInput = false;
bool g_WasScreenOpen = false;
bool g_HaveLastSet = false;
bool g_Busy = false;
std::uint64_t g_LastTeleportAt = 0;
std::uint64_t g_LastStatusAt = 0;
std::uint64_t g_StartedAt = 0;
std::uint32_t g_WorldId = 0;
std::uint32_t g_CollisionEpoch = 0;
std::uint32_t g_TeleportSequence = 0;
std::uint32_t g_ViewportW = 0, g_ViewportH = 0;
// Where the Minecraft player looks (Minecraft degrees). While Minecraft drives, this is turned here
// from the raw mouse with Minecraft's own sensitivity; otherwise it follows the game's camera.
float g_Yaw = 0.f, g_Pitch = 0.f;
float g_PedHeight = 1.0f; // the game reports a character's middle, Minecraft wants the feet
float g_CursorX = 0.f, g_CursorY = 0.f;
int g_LastCursorSentX = -1, g_LastCursorSentY = -1;
int g_FrameMouseX = 0, g_FrameMouseY = 0;
Cam g_Camera = 0;
Vec3 g_LastSafe, g_TeleportTarget, g_LastSetPosition, g_LastTarget;
bool g_HaveLastTarget = false;
std::uint64_t g_LastFloorRescue = 0;
std::uint32_t g_Random = 0x9E3779B9u;
std::uint64_t g_Surfels = 0;
std::array<bool, 256> g_KeyStates {};
std::array<std::uint64_t, 256> g_KeyRepeatAt {};
std::array<bool, 5> g_MouseStates {};

struct Npc {
    Ped ped;
    Vec3 feet;
    bool dead;
};
std::vector<Npc> g_Npcs;
std::vector<Renderer::Hazard> g_Hazards;
std::unordered_map<int, std::uint64_t> g_BurnedAt;
std::uint64_t g_LastNpcScan = 0, g_LastHazardCheck = 0;

// Mouse movement and wheel, picked up from the game window's raw input.
WNDPROC g_OriginalWindowProc = nullptr;
HWND g_HookedWindow = nullptr;
std::atomic<int> g_MouseDeltaX = 0, g_MouseDeltaY = 0, g_WheelDelta = 0;
std::atomic_bool g_RawMouseSeen = false;

struct KeyMap {
    int virtualKey;
    std::uint16_t sdl; // SDL scancode == USB HID usage, what Minecraft 26 reads
};

const std::vector<KeyMap>& Keys() {
    static const std::vector<KeyMap> keys = [] {
        std::vector<KeyMap> list;
        for (int letter = 'A'; letter <= 'Z'; ++letter)
            list.push_back({ letter, static_cast<std::uint16_t>(4 + letter - 'A') });
        for (int digit = '1'; digit <= '9'; ++digit)
            list.push_back({ digit, static_cast<std::uint16_t>(30 + digit - '1') });
        list.push_back({ '0', 39 });
        for (int function = 0; function < 12; ++function) {
            if (VK_F1 + function != kToggleDriveKey)
                list.push_back({ VK_F1 + function, static_cast<std::uint16_t>(58 + function) });
        }
        const KeyMap others[] = {
            { VK_RETURN, 40 }, { VK_ESCAPE, 41 }, { VK_BACK, 42 }, { VK_TAB, 43 }, { VK_SPACE, 44 },
            { VK_OEM_MINUS, 45 }, { VK_OEM_PLUS, 46 }, { VK_OEM_4, 47 }, { VK_OEM_6, 48 }, { VK_OEM_5, 49 },
            { VK_OEM_1, 51 }, { VK_OEM_7, 52 }, { VK_OEM_COMMA, 54 }, { VK_OEM_PERIOD, 55 }, { VK_OEM_2, 56 },
            { VK_INSERT, 73 }, { VK_HOME, 74 }, { VK_PRIOR, 75 }, { VK_DELETE, 76 }, { VK_END, 77 }, { VK_NEXT, 78 },
            { VK_RIGHT, 79 }, { VK_LEFT, 80 }, { VK_DOWN, 81 }, { VK_UP, 82 },
            { VK_LCONTROL, 224 }, { VK_LSHIFT, 225 }, { VK_LMENU, 226 },
            { VK_RCONTROL, 228 }, { VK_RSHIFT, 229 }, { VK_RMENU, 230 },
        };
        list.insert(list.end(), std::begin(others), std::end(others));
        return list;
    }();
    return keys;
}

bool KeyDown(int p_VirtualKey) {
    return (::GetAsyncKeyState(p_VirtualKey) & 0x8000) != 0;
}

float Distance(const Vec3& p_A, const Vec3& p_B) {
    return std::sqrt((p_A.x - p_B.x) * (p_A.x - p_B.x) + (p_A.y - p_B.y) * (p_A.y - p_B.y) + (p_A.z - p_B.z) * (p_A.z - p_B.z));
}

// ---------------------------------------------------------------------------------------------
// Ray casts
// ---------------------------------------------------------------------------------------------

bool CastFlags(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit, Vec3* p_Normal, int p_Flags) {
    const int handle = N::StartShapeTestRay(p_From.x, p_From.y, p_From.z, p_To.x, p_To.y, p_To.z, p_Flags, g_Ped);
    BOOL hit = FALSE;
    Vector3 end {}, normal {};
    Entity entity = 0;
    if (N::GetShapeTestResult(handle, &hit, &end, &normal, &entity) != 2 || !hit)
        return false;
    p_Hit = { end.x, end.y, end.z };
    if (p_Normal)
        *p_Normal = { normal.x, normal.y, normal.z };
    return true;
}

bool Raycast(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit) {
    return CastFlags(p_From, p_To, p_Hit, nullptr, kRayWorld);
}

bool RaycastMoving(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit) {
    return CastFlags(p_From, p_To, p_Hit, nullptr, kRayMoving);
}

// ---------------------------------------------------------------------------------------------
// Minecraft
// ---------------------------------------------------------------------------------------------

bool MinecraftRunning() {
    const HANDLE mutex = ::OpenMutexW(SYNCHRONIZE, FALSE, kMinecraftMutexName);
    if (!mutex)
        return false;
    ::CloseHandle(mutex);
    return true;
}

void TryLaunchMinecraft() {
    g_LaunchAttempted = true;
    if (MinecraftRunning()) {
        HcLog("Minecraft is already running; not starting another");
        return;
    }
    wchar_t localAppData[MAX_PATH] {};
    const auto length = ::GetEnvironmentVariableW(L"LOCALAPPDATA", localAppData, MAX_PATH);
    if (!length || length >= MAX_PATH)
        return;
    const std::wstring root = std::wstring(localAppData) + L"\\SkyCraft\\Prism";
    const std::wstring launcher = root + L"\\prismlauncher.exe";
    if (::GetFileAttributesW(launcher.c_str()) == INVALID_FILE_ATTRIBUTES) {
        HcLog("the bundled Prism Launcher was not found under %%LOCALAPPDATA%%\\SkyCraft\\Prism");
        return;
    }
    const auto result = reinterpret_cast<std::intptr_t>(::ShellExecuteW(
        nullptr, L"open", launcher.c_str(), L"--launch SkyCraft", root.c_str(), SW_SHOWMINNOACTIVE));
    HcLog(result > 32 ? "started the bundled SkyCraft Minecraft instance" : "Prism Launcher failed to start");
}

// ---------------------------------------------------------------------------------------------
// Input
// ---------------------------------------------------------------------------------------------

LRESULT CALLBACK WindowProc(HWND p_Window, UINT p_Message, WPARAM p_Wparam, LPARAM p_Lparam) {
    if (p_Message == WM_INPUT) {
        RAWINPUT input {};
        UINT size = sizeof(input);
        if (::GetRawInputData(reinterpret_cast<HRAWINPUT>(p_Lparam), RID_INPUT, &input, &size, sizeof(RAWINPUTHEADER)) != UINT(-1) &&
            input.header.dwType == RIM_TYPEMOUSE) {
            g_RawMouseSeen.store(true, std::memory_order_relaxed);
            if (!(input.data.mouse.usFlags & MOUSE_MOVE_ABSOLUTE)) {
                g_MouseDeltaX.fetch_add(input.data.mouse.lLastX, std::memory_order_relaxed);
                g_MouseDeltaY.fetch_add(input.data.mouse.lLastY, std::memory_order_relaxed);
            }
            if (input.data.mouse.usButtonFlags & RI_MOUSE_WHEEL)
                g_WheelDelta.fetch_add(static_cast<short>(input.data.mouse.usButtonData), std::memory_order_relaxed);
        }
    } else if (p_Message == WM_MOUSEWHEEL && !g_RawMouseSeen.load(std::memory_order_relaxed)) {
        g_WheelDelta.fetch_add(GET_WHEEL_DELTA_WPARAM(p_Wparam), std::memory_order_relaxed);
    }
    return ::CallWindowProcW(g_OriginalWindowProc, p_Window, p_Message, p_Wparam, p_Lparam);
}

BOOL CALLBACK FindGameWindow(HWND p_Window, LPARAM p_Result) {
    DWORD pid = 0;
    ::GetWindowThreadProcessId(p_Window, &pid);
    if (pid != ::GetCurrentProcessId() || !::IsWindowVisible(p_Window) || ::GetWindow(p_Window, GW_OWNER))
        return TRUE;
    RECT rect {};
    ::GetClientRect(p_Window, &rect);
    if (rect.right < 320 || rect.bottom < 200)
        return TRUE;
    *reinterpret_cast<HWND*>(p_Result) = p_Window;
    return FALSE;
}

void HookWindow() {
    if (g_HookedWindow)
        return;
    HWND window = Renderer::Window();
    if (!window)
        ::EnumWindows(&FindGameWindow, reinterpret_cast<LPARAM>(&window));
    if (!window)
        return;
    const auto previous = reinterpret_cast<WNDPROC>(::SetWindowLongPtrW(window, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(&WindowProc)));
    if (previous) {
        g_OriginalWindowProc = previous;
        g_HookedWindow = window;
        HcLog("input: watching the game window %p for mouse movement and wheel", static_cast<void*>(window));
    }
}

void ReleaseInput() {
    g_WasScreenOpen = false;
    Renderer::SetCursor(false, 0.f, 0.f);
    if (!g_WasForwardingInput)
        return;
    g_Link.PushInput(kInReleaseAll, 0);
    g_KeyStates.fill(false);
    g_MouseStates.fill(false);
    g_WheelDelta.store(0);
    g_WasForwardingInput = false;
}

// The character a key types, for Minecraft's chat, signs, anvils and search boxes.
void SendText(int p_VirtualKey) {
    if (KeyDown(VK_CONTROL) || KeyDown(VK_MENU))
        return;
    BYTE state[256] {};
    if (KeyDown(VK_SHIFT))
        state[VK_SHIFT] = 0x80;
    if (::GetKeyState(VK_CAPITAL) & 1)
        state[VK_CAPITAL] = 0x01;
    state[p_VirtualKey & 0xFF] = 0x80;
    wchar_t characters[4] {};
    const int count = ::ToUnicode(p_VirtualKey, ::MapVirtualKeyW(p_VirtualKey, MAPVK_VK_TO_VSC), state, characters, 4, 0);
    if (count >= 1 && characters[0] >= 32 && characters[0] != 127)
        g_Link.PushInput(kInText, 0, characters[0]);
}

void ForwardInput(bool p_ScreenOpen) {
    DWORD foregroundPid = 0;
    ::GetWindowThreadProcessId(::GetForegroundWindow(), &foregroundPid);
    if (foregroundPid != ::GetCurrentProcessId()) {
        ReleaseInput();
        return;
    }

    const auto now = ::GetTickCount64();
    for (const auto& key : Keys()) {
        bool down = KeyDown(key.virtualKey);
        if (!p_ScreenOpen) {
            // In the world, Esc is the game's pause menu and O opens Minecraft's own menu.
            if (key.virtualKey == VK_ESCAPE)
                down = false;
            if (key.virtualKey == 'O') {
                if (down && !g_KeyStates[key.sdl]) {
                    g_Link.PushInput(kInReleaseAll, 0);
                    g_Link.PushInput(kInOpenMenu, 0);
                }
                g_KeyStates[key.sdl] = down;
                continue;
            }
        }
        if (g_KeyStates[key.sdl] != down) {
            g_KeyStates[key.sdl] = down;
            g_Link.PushInput(kInKey, key.sdl, down ? 1 : 0);
            if (down && p_ScreenOpen) {
                SendText(key.virtualKey);
                g_KeyRepeatAt[key.sdl] = now + 450;
            }
        } else if (down && p_ScreenOpen && now >= g_KeyRepeatAt[key.sdl]) {
            g_Link.PushInput(kInKey, key.sdl, 1);
            SendText(key.virtualKey);
            g_KeyRepeatAt[key.sdl] = now + 45;
        }
    }

    static constexpr int mouseKeys[] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 };
    static constexpr std::uint16_t mouseCodes[] = { 1, 3, 2, 4, 5 };
    for (std::size_t i = 0; i < std::size(mouseKeys); ++i) {
        const bool down = KeyDown(mouseKeys[i]);
        if (g_MouseStates[i] != down) {
            g_MouseStates[i] = down;
            g_Link.PushInput(kInMouseButton, mouseCodes[i], down ? 1 : 0);
        }
    }

    if (const int wheel = g_WheelDelta.exchange(0))
        g_Link.PushInput(kInScroll, 0, wheel);

    if (p_ScreenOpen && g_ViewportW > 0 && g_ViewportH > 0) {
        if (!g_WasScreenOpen) {
            g_CursorX = g_ViewportW * 0.5f;
            g_CursorY = g_ViewportH * 0.5f;
            g_LastCursorSentX = g_LastCursorSentY = -1;
        }
        if (g_RawMouseSeen.load(std::memory_order_relaxed)) {
            g_CursorX += static_cast<float>(g_FrameMouseX);
            g_CursorY += static_cast<float>(g_FrameMouseY);
        } else if (g_HookedWindow) {
            POINT point {};
            RECT client {};
            if (::GetCursorPos(&point) && ::ScreenToClient(g_HookedWindow, &point) && ::GetClientRect(g_HookedWindow, &client) &&
                client.right > 0 && client.bottom > 0) {
                g_CursorX = static_cast<float>(point.x) * g_ViewportW / client.right;
                g_CursorY = static_cast<float>(point.y) * g_ViewportH / client.bottom;
            }
        }
        g_CursorX = std::clamp(g_CursorX, 0.f, static_cast<float>(g_ViewportW - 1));
        g_CursorY = std::clamp(g_CursorY, 0.f, static_cast<float>(g_ViewportH - 1));
        const int x = static_cast<int>(g_CursorX), y = static_cast<int>(g_CursorY);
        if (x != g_LastCursorSentX || y != g_LastCursorSentY) {
            g_LastCursorSentX = x;
            g_LastCursorSentY = y;
            g_Link.PushInput(kInCursor, 0, x, y);
        }
        Renderer::SetCursor(true, g_CursorX, g_CursorY);
    } else {
        Renderer::SetCursor(false, 0.f, 0.f);
    }
    g_WasScreenOpen = p_ScreenOpen;
    g_WasForwardingInput = true;
}

// ---------------------------------------------------------------------------------------------
// Driving the player
// ---------------------------------------------------------------------------------------------

void RequestTeleport(const Vec3& p_Feet, const char* p_Reason) {
    g_NeedTeleport = false;
    ++g_TeleportSequence;
    g_TeleportTarget = p_Feet;
    g_LastSafe = p_Feet;
    g_LastTeleportAt = ::GetTickCount64();
    HcLog("asking Minecraft to come to the player at mc %.2f %.2f %.2f (%s, teleport %u)", p_Feet.x, p_Feet.z, -p_Feet.y, p_Reason,
        g_TeleportSequence);
}

// Minecraft takes the player over: the game's character is held still, hidden and unhurt (the
// Minecraft player is what is seen and what takes damage), and the picture comes from a camera of
// our own at the Minecraft player's eyes. Giving it back undoes all of that.
void SetDriving(bool p_Driving) {
    if (p_Driving == g_Driving)
        return;
    g_Driving = p_Driving;
    HcLog("Minecraft %s the player", p_Driving ? "now drives" : "no longer drives");
    if (N::DoesEntityExist(g_Ped)) {
        N::FreezeEntityPosition(g_Ped, p_Driving);
        N::SetEntityVisible(g_Ped, !p_Driving);
        N::SetEntityInvincible(g_Ped, p_Driving);
        if (!p_Driving)
            N::SetEntityVelocity(g_Ped, 0.f, 0.f, 0.f);
    }
    if (p_Driving) {
        if (!g_Camera) {
            g_Camera = N::CreateCam("DEFAULT_SCRIPTED_CAMERA");
            N::SetCamNearClip(g_Camera, 0.05f);
        }
        N::SetCamActive(g_Camera, true);
        N::RenderScriptCams(true);
    } else {
        N::RenderScriptCams(false);
        if (g_Camera) {
            N::SetCamActive(g_Camera, false);
            N::DestroyCam(g_Camera);
            g_Camera = 0;
        }
        ReleaseInput();
    }
}

void WriteIdleState(std::uint32_t p_Flags) {
    SkyState state {};
    state.flags = p_Flags;
    state.worldId = g_WorldId;
    state.collisionEpoch = g_CollisionEpoch;
    state.teleportSeq = g_TeleportSequence;
    state.viewportW = g_ViewportW;
    state.viewportH = g_ViewportH;
    state.gameHour = 12.f;
    g_Link.WriteHostState(state);
}

// A share of a character's health (percent of its maximum), credited to the player.
void DamageNpc(Ped p_Ped, float p_Percent) {
    if (!N::DoesEntityExist(p_Ped) || N::IsEntityDead(p_Ped))
        return;
    const int maximum = std::max(N::GetEntityMaxHealth(p_Ped), 1);
    const int health = N::GetEntityHealth(p_Ped);
    const int damage = std::max(1, static_cast<int>(maximum * p_Percent / 100.f));
    N::SetEntityHealth(p_Ped, std::max(health - damage, 0), g_Ped);
    // Health alone changes silently: anything but a scratch also knocks them off their feet, so a
    // hit looks like a hit.
    if (p_Percent >= 15.f && health - damage > 0)
        N::SetPedToRagdoll(p_Ped, 900, 1500);
    static int logged = 0;
    if (logged++ < 60)
        HcLog("damage: character %d health %d of %d takes %d%s", p_Ped, health, maximum, damage, health - damage <= 0 ? " (fatal)" : "");
}

void Tick() {
    if (!g_Link.Valid())
        return;
    const auto now = ::GetTickCount64();
    g_Link.Heartbeat();

    static bool rendererLinked = false;
    if (!rendererLinked) {
        Renderer::SetLink(&g_Link);
        rendererLinked = true;
    }
    Renderer::Install();
    HookWindow();
    g_FrameMouseX = g_MouseDeltaX.exchange(0);
    g_FrameMouseY = g_MouseDeltaY.exchange(0);

    const bool toggleDown = KeyDown(kToggleDriveKey);
    if (toggleDown && !g_ToggleKeyDown) {
        g_DriveWanted = !g_DriveWanted;
        HcLog("F10: Minecraft control %s", g_DriveWanted ? "on" : "off");
    }
    g_ToggleKeyDown = toggleDown;

    // Minecraft renders its picture at the game's resolution (capped at 1080p; it stretches fine).
    if (const std::uint32_t width = Renderer::Width(), height = Renderer::Height(); width >= 320 && height >= 200) {
        const float scale = std::min(1.f, std::min(1920.f / width, 1080.f / height));
        g_ViewportW = static_cast<std::uint32_t>(width * scale) & ~1u;
        g_ViewportH = static_cast<std::uint32_t>(height * scale) & ~1u;
    } else if (g_ViewportW == 0) {
        g_ViewportW = 1920; // no picture hook yet (Vulkan): Minecraft still needs a size
        g_ViewportH = 1080;
    }

    const bool minecraftAlive = g_Link.MinecraftAlive();
    if (minecraftAlive != g_MinecraftWasAlive) {
        g_MinecraftWasAlive = minecraftAlive;
        HcLog("Minecraft %s (pid %u)", minecraftAlive ? "connected" : "went away", g_Link.MinecraftPid());
        if (minecraftAlive) {
            ++g_CollisionEpoch;
            g_Link.WriteCollision(kColClear, &g_CollisionEpoch, sizeof(g_CollisionEpoch));
            g_Collision.ForgetSent();
            g_NeedTeleport = true;
        } else {
            g_MinecraftWasInWorld = false;
        }
    }
    if (!minecraftAlive && !g_LaunchAttempted && now - g_StartedAt >= 1000)
        TryLaunchMinecraft();

    const Player player = N::PlayerId();
    g_Ped = N::PlayerPed();
    const bool hasPlayer = N::DoesEntityExist(g_Ped) && N::IsPlayerPlaying(player);
    if (!hasPlayer) {
        if (g_HadPlayer) {
            g_HadPlayer = false;
            HcLog("player gone (loading or dead)");
        }
        SetDriving(false);
        ReleaseInput();
        Renderer::SetCamera({}, false);
        Renderer::SetEnabled(false);
        WriteIdleState(0);
        return;
    }

    const Vector3 origin = N::GetEntityCoords(g_Ped);
    Vec3 feet { origin.x, origin.y, origin.z - g_PedHeight };
    if (!g_HadPlayer) {
        g_HadPlayer = true;
        ++g_WorldId;
        ++g_CollisionEpoch;
        g_Collision.Reset();
        if (minecraftAlive)
            g_Link.WriteCollision(kColClear, &g_CollisionEpoch, sizeof(g_CollisionEpoch));
        g_NeedTeleport = true;
        g_HaveLastSet = false;
        HcLog("player in the world (world %u) at %.2f %.2f %.2f", g_WorldId, origin.x, origin.y, origin.z);
    }
    Renderer::SetEnabled(true);

    const bool paused = N::IsPauseMenuActive();
    // Riding, driving, a cutscene or a scripted moment: the game needs the player for itself.
    const bool busy = N::IsPedOnMount(g_Ped) || N::IsPedInAnyVehicle(g_Ped) || !N::IsPlayerControlOn(player) || N::IsEntityDead(g_Ped);
    if (busy != g_Busy) {
        g_Busy = busy;
        HcLog(busy ? "the game has the player (mount, vehicle, cutscene or death)" : "the player is free again");
        if (!busy)
            g_NeedTeleport = true;
    }

    // How far above the feet the game's "position" of the character is: measured, on foot and standing.
    if (!g_Driving && !busy && !paused) {
        Vec3 ground;
        if (Raycast({ origin.x, origin.y, origin.z }, { origin.x, origin.y, origin.z - 3.f }, ground)) {
            const float height = origin.z - ground.z;
            if (height > 0.6f && height < 1.4f)
                g_PedHeight += (height - g_PedHeight) * 0.2f;
        }
        feet.z = origin.z - g_PedHeight;
    }

    McState minecraft {};
    const bool inWorld = minecraftAlive && g_Link.ReadMinecraftState(minecraft) && (minecraft.flags & kMcInWorld) != 0;
    const bool screenOpen = inWorld && (minecraft.flags & kMcScreenOpen) != 0;
    if (inWorld && !g_MinecraftWasInWorld) {
        g_NeedTeleport = true;
        HcLog("Minecraft is in its world");
    }
    g_MinecraftWasInWorld = inWorld;
    if (g_DriveWanted && !g_DriveWasWanted)
        g_NeedTeleport = true;
    g_DriveWasWanted = g_DriveWanted;

    // A mission may move the character by itself: follow it instead of dragging it back.
    if (g_Driving && g_HaveLastSet && now - g_LastTeleportAt > 1500 && Distance(feet, g_LastSetPosition) > 8.f) {
        g_HaveLastSet = false;
        RequestTeleport(feet, "the game moved the player");
    } else if (g_NeedTeleport && inWorld && g_DriveWanted && !busy) {
        RequestTeleport(feet, "start");
    } else if (g_DriveWanted && inWorld && !busy && minecraft.teleportAck != g_TeleportSequence && now - g_LastTeleportAt > 1500 &&
        Distance(feet, g_TeleportTarget) > 2.f) {
        RequestTeleport(feet, "the player moved before Minecraft arrived");
    }

    // "Arrived" = Minecraft took the teleport and the collision around it has reached it.
    const bool arrived = inWorld && minecraft.teleportAck == g_TeleportSequence;
    bool driving = g_DriveWanted && arrived && !paused && !busy;

    if (!g_Driving) {
        // Until Minecraft takes over, it looks where the game's camera looks.
        const Vector3 rotation = N::GetGameplayCamRot();
        g_Yaw = 180.f - rotation.z;
        g_Pitch = -rotation.x;
    } else if (driving && !screenOpen) {
        // Minecraft's own mouse formula: sensitivity s -> (0.6 s + 0.2)^3 * 8 * 0.15 degrees per count.
        const float s = (minecraft.sensitivity > 0.f ? minecraft.sensitivity : 0.5f) * 0.6f + 0.2f;
        const float degreesPerCount = s * s * s * 8.f * 0.15f;
        g_Yaw += static_cast<float>(g_FrameMouseX) * degreesPerCount;
        g_Pitch = std::clamp(g_Pitch + static_cast<float>(g_FrameMouseY) * degreesPerCount, -90.f, 90.f);
    }
    while (g_Yaw > 180.f)
        g_Yaw -= 360.f;
    while (g_Yaw < -180.f)
        g_Yaw += 360.f;

    Game::Camera camera;
    bool haveCamera = false;
    if (driving) {
        const Vec3 target { static_cast<float>(minecraft.x), static_cast<float>(-minecraft.z), static_cast<float>(minecraft.y) };
        if (minecraft.flags & kMcOnGround)
            g_LastSafe = target;

        // Did Minecraft's player just drop through a floor the game really has? Patch the hole
        // and put the player back on the real floor.
        if (g_HaveLastTarget && now - g_LastFloorRescue > 700 && now - g_LastTeleportAt > 700) {
            const float fell = g_LastTarget.z - target.z;
            const float sideways = std::hypot(target.x - g_LastTarget.x, target.y - g_LastTarget.y);
            Vec3 floor;
            if (fell > 0.2f && fell < 20.f && sideways < fell + 0.5f &&
                Raycast({ g_LastTarget.x, g_LastTarget.y, g_LastTarget.z + 0.35f }, { target.x, target.y, target.z + 0.35f }, floor)) {
                g_LastFloorRescue = now;
                for (float dx = -1.5f; dx <= 1.5f; dx += 0.5f) {
                    for (float dy = -1.5f; dy <= 1.5f; dy += 0.5f) {
                        Vec3 patch;
                        if (Raycast({ floor.x + dx, floor.y + dy, floor.z + 0.6f }, { floor.x + dx, floor.y + dy, floor.z - 0.6f }, patch))
                            g_Collision.AddSurfel(patch, { 0.f, 0.f, 1.f });
                    }
                }
                static int logged = 0;
                if (logged++ < 20)
                    HcLog("Minecraft's player fell through a real floor at %.1f %.1f %.1f; patched and put back", floor.x, floor.y, floor.z);
                g_HaveLastTarget = false;
                feet = { floor.x, floor.y, floor.z + 0.05f };
                RequestTeleport(feet, "fell through a floor");
                driving = false;
            }
        }
        if (driving) {
            g_LastTarget = target;
            g_HaveLastTarget = true;
            if (target.z < g_LastSafe.z - 80.f) {
                feet = g_LastSafe;
                RequestTeleport(feet, "fell out of the world");
                driving = false;
            } else {
                feet = target;
            }
        }
        N::SetEntityCoordsNoOffset(g_Ped, feet.x, feet.y, feet.z + g_PedHeight);
        N::SetEntityHeading(g_Ped, 180.f - g_Yaw);
        g_LastSetPosition = feet;
        g_HaveLastSet = driving;
    } else if (!paused) {
        g_HaveLastSet = false;
        g_HaveLastTarget = false;
    }
    SetDriving(driving);

    if (driving) {
        // Every game control off (shooting, weapon wheel, the game's own movement and camera); the
        // pause menu is a different control group and still answers to Esc.
        N::DisableAllControlActions(0);

        // The camera: at the Minecraft player's eyes, or where Minecraft's F5 views would put it.
        Vec3 eye { feet.x, feet.y, feet.z + 1.62f };
        if (minecraft.eyeX != 0.0 || minecraft.eyeY != 0.0 || minecraft.eyeZ != 0.0)
            eye = { static_cast<float>(minecraft.eyeX), static_cast<float>(-minecraft.eyeZ), static_cast<float>(minecraft.eyeY) };
        // In the game's terms: heading 0 faces +Y and grows to the left; pitch grows upward.
        float heading = 180.f - g_Yaw, pitch = -g_Pitch;
        const auto forwardOf = [](float p_Heading, float p_Pitch) {
            const float h = p_Heading * kDegreesToRadians, p = p_Pitch * kDegreesToRadians;
            return Vec3 { -std::sin(h) * std::cos(p), std::cos(h) * std::cos(p), std::sin(p) };
        };
        const Vec3 look = forwardOf(heading, pitch);
        const std::uint32_t mode = std::min<std::uint32_t>(minecraft.cameraMode, 2);
        if (mode != 0) {
            const float distance = std::clamp(minecraft.cameraDistance > 0.05f ? minecraft.cameraDistance : 4.f, 0.3f, 4.f);
            const float side = mode == 1 ? -1.f : 1.f; // behind, or in front looking back
            eye = { eye.x + look.x * distance * side, eye.y + look.y * distance * side, eye.z + look.z * distance * side };
            if (mode == 2) {
                heading += 180.f;
                pitch = -pitch;
            }
        }
        const float fov = minecraft.fovDeg > 20.f && minecraft.fovDeg < 150.f ? minecraft.fovDeg : 70.f;
        N::SetCamCoord(g_Camera, eye.x, eye.y, eye.z);
        N::SetCamRot(g_Camera, pitch, 0.f, heading);
        N::SetCamFov(g_Camera, fov);

        camera.position = eye;
        camera.forward = forwardOf(heading, pitch);
        const float h = heading * kDegreesToRadians;
        camera.right = { std::cos(h), std::sin(h), 0.f };
        camera.up = { camera.right.y * camera.forward.z - camera.right.z * camera.forward.y,
            camera.right.z * camera.forward.x - camera.right.x * camera.forward.z,
            camera.right.x * camera.forward.y - camera.right.y * camera.forward.x };
        camera.scaleY = 1.f / std::tan(fov * 0.5f * kDegreesToRadians); // the field of view is vertical
        camera.scaleX = 0.f;
        haveCamera = true;
        Renderer::SetPlayer(feet, g_Yaw, true, mode != 0);
    } else {
        Renderer::SetPlayer(feet, g_Yaw, false, false);
    }
    Renderer::SetCamera(camera, haveCamera);

    SkyState state {};
    state.flags = kSkyInGame | (paused ? kSkyMenuOpen : 0u);
    state.worldId = g_WorldId;
    state.collisionEpoch = g_CollisionEpoch;
    state.posX = feet.x;
    state.posY = feet.z;
    state.posZ = -feet.y;
    state.yaw = g_Yaw;
    state.pitch = g_Pitch;
    state.teleportSeq = g_TeleportSequence;
    state.viewportW = g_ViewportW;
    state.viewportH = g_ViewportH;
    state.gameHour = 12.f;
    g_Link.WriteHostState(state);

    // Look around with rays: whatever can be seen becomes something arrows, the crosshair and the
    // player can hit (the flood fill only knows what can be walked to).
    if (!paused && haveCamera && minecraftAlive) {
        const auto random = [] {
            g_Random ^= g_Random << 13;
            g_Random ^= g_Random >> 17;
            g_Random ^= g_Random << 5;
            return static_cast<float>(g_Random & 0xFFFF) / 32767.5f - 1.f; // -1..1
        };
        for (int ray = 0; ray < 40; ++ray) {
            Vec3 direction;
            if (ray % 5 == 4) {
                direction = { random(), random(), random() };
            } else {
                const float side = random() * 1.3f, rise = random() * 0.9f;
                direction = { camera.forward.x + camera.right.x * side + camera.up.x * rise,
                    camera.forward.y + camera.right.y * side + camera.up.y * rise,
                    camera.forward.z + camera.right.z * side + camera.up.z * rise };
            }
            const float length = std::sqrt(direction.x * direction.x + direction.y * direction.y + direction.z * direction.z);
            if (length < 0.05f)
                continue;
            direction = { direction.x / length, direction.y / length, direction.z / length };
            const Vec3 from { camera.position.x + direction.x * 0.3f, camera.position.y + direction.y * 0.3f, camera.position.z + direction.z * 0.3f };
            const Vec3 to { from.x + direction.x * 64.f, from.y + direction.y * 64.f, from.z + direction.z * 64.f };
            Vec3 hit, normal;
            if (!CastFlags(from, to, hit, &normal, kRayWorld))
                continue;
            if (normal.x * normal.x + normal.y * normal.y + normal.z * normal.z < 0.25f)
                normal = { -direction.x, -direction.y, -direction.z };
            g_Collision.AddSurfel(hit, normal);
            ++g_Surfels;
        }
    }

    if (!paused && !busy)
        g_Collision.Update(g_Link, g_CollisionEpoch, feet, minecraftAlive);

    // Minecraft's explosions and hits happen in the game too.
    if (minecraftAlive) {
        g_Link.DrainEvents([](const McEvent& p_Event) {
            if (p_Event.type == kEvExplosion) {
                // A real explosion: it hurts people, animals, wagons, and throws things about.
                N::AddExplosion(p_Event.a, -p_Event.c, p_Event.b, 0, std::clamp(p_Event.d / 4.f, 0.5f, 3.f));
                HcLog("explosion: at %.1f %.1f %.1f, Minecraft radius %.1f", p_Event.a, -p_Event.c, p_Event.b, p_Event.d);
            } else if (p_Event.type == kEvHitActor) {
                // Scaled so a sword or an arrow kills in one or two and a fist in a handful.
                const Ped ped = static_cast<Ped>(p_Event.formId);
                static int logged = 0;
                if (logged++ < 60)
                    HcLog("hit: character %d, Minecraft damage %.1f, flags %u (%s)", ped, p_Event.a, p_Event.flags,
                        (p_Event.flags & 2) ? "arrow or thrown" : "melee");
                DamageNpc(ped, std::clamp(p_Event.a * 6.f, 20.f, 100.f));
                if ((p_Event.flags & kHitFire) && N::DoesEntityExist(ped))
                    N::StartEntityFire(ped);
            }
        });
    }

    // People and animals near the player, mirrored into Minecraft as invisible stand-ins so that
    // swords and arrows can hit them, and checked against Minecraft's fire and lava.
    if (minecraftAlive && inWorld && !paused && now - g_LastNpcScan >= 100) {
        g_LastNpcScan = now;
        static int handles[1024];
        const int count = worldGetAllPeds(handles, 1024);
        g_Npcs.clear();
        static std::vector<ActorRecord> records;
        records.clear();
        for (int i = 0; i < count && records.size() < kMaxActors; ++i) {
            const Ped ped = handles[i];
            if (ped == g_Ped || !N::DoesEntityExist(ped))
                continue;
            const Vector3 position = N::GetEntityCoords(ped);
            Npc npc { ped, { position.x, position.y, position.z - 1.0f }, N::IsEntityDead(ped) };
            if (Distance(npc.feet, feet) > 40.f)
                continue;
            g_Npcs.push_back(npc);

            ActorRecord record {};
            record.formId = static_cast<std::uint32_t>(ped);
            record.flags = npc.dead ? kActorDead : 0u;
            // Minecraft only reaches 3 blocks: nearby characters get a wider box that leans in toward
            // the player (melee range about 5.5 m); far ones stay put so arrows have to really hit.
            Vec3 stand = npc.feet;
            const float dx = feet.x - stand.x, dy = feet.y - stand.y;
            const float distance = std::sqrt(dx * dx + dy * dy);
            if (distance > 1.f && distance < 6.5f) {
                const float lean = std::min(distance - 1.f, 2.5f) / distance;
                stand.x += dx * lean;
                stand.y += dy * lean;
            }
            record.x = stand.x;
            record.y = stand.z;
            record.z = -stand.y;
            record.width = 1.0f;
            record.height = 2.0f;
            record.healthFrac = npc.dead ? 0.f : 1.f;
            record.level = 1;
            std::memcpy(record.name, "Stranger", 9);
            records.push_back(record);
        }
        g_Link.WriteActors(records.data(), static_cast<std::uint32_t>(records.size()));

        if (now - g_LastHazardCheck >= 500) {
            g_LastHazardCheck = now;
            Renderer::CopyHazards(g_Hazards);
            for (const auto& npc : g_Npcs) {
                if (npc.dead || g_Hazards.empty())
                    continue;
                const float x = npc.feet.x, y = npc.feet.z, z = -npc.feet.y; // Minecraft axes
                bool burning = false;
                for (const auto& hazard : g_Hazards) {
                    const float bottom = hazard.kind == 3 ? hazard.y + 0.8f : hazard.y - 0.3f;
                    const float top = hazard.kind == 3 ? hazard.y + 1.4f : hazard.y + 1.2f;
                    if (x > hazard.x - 0.3f && x < hazard.x + 1.3f && z > hazard.z - 0.3f && z < hazard.z + 1.3f && y > bottom && y < top) {
                        burning = true;
                        break;
                    }
                }
                if (!burning)
                    continue;
                auto& last = g_BurnedAt[npc.ped];
                if (now - last < 2000)
                    continue;
                last = now;
                N::StartEntityFire(npc.ped);
            }
            if (g_BurnedAt.size() > 2000)
                g_BurnedAt.clear();
        }
    }

    if (driving)
        ForwardInput(screenOpen);
    else
        ReleaseInput();

    if (now - g_LastStatusAt > 10000) {
        g_LastStatusAt = now;
        const auto& stats = g_Collision.GetStats();
        HcLog("status: minecraft %s, %s; scan %u points %u triangles %u regions (%s, %llu rays, %llu hits)",
            minecraftAlive ? (inWorld ? "in world" : "connected") : "absent",
            driving ? "driving the player" : !g_DriveWanted ? "control off (F10)" : paused ? "game paused" : busy ? "game has the player" : "not arrived yet",
            stats.nodes, stats.triangles, stats.regionsSent, stats.hasGround ? "ground found" : "NO GROUND",
            static_cast<unsigned long long>(stats.rays), static_cast<unsigned long long>(stats.hits));
        HcLog("status: picture %ux%u, %llu Minecraft frames, %zu block sections, %llu DirectX 12 presents%s", g_ViewportW, g_ViewportH,
            static_cast<unsigned long long>(Renderer::OverlayFrames()), Renderer::Sections(),
            static_cast<unsigned long long>(Renderer::Presents()),
            Renderer::Presents() == 0 ? " (NONE: set Graphics API to DirectX 12 in the game's settings, or nothing can be drawn)" : "");
        HcLog("status: %zu characters mirrored, %zu fire/lava blocks, %llu view-ray hits, raw mouse %s, character height %.2f",
            g_Npcs.size(), g_Hazards.size(), static_cast<unsigned long long>(g_Surfels),
            g_RawMouseSeen.load() ? "seen" : "NOT seen", g_PedHeight);
    }
}

void ScriptMain() {
    HcLog("script started (the game world is up)");
    g_StartedAt = ::GetTickCount64();
    while (true) {
        Tick();
        WAIT(0);
    }
}
}

BOOL APIENTRY DllMain(HMODULE p_Module, DWORD p_Reason, LPVOID) {
    switch (p_Reason) {
    case DLL_PROCESS_ATTACH: {
        HcLog("RedCraft starting");
        g_Link.Create();
        g_Collision.SetRaycaster(&Raycast);
        g_Collision.SetFloorFallback(&RaycastMoving);
        // Somewhere new each run, so a Minecraft still acknowledging the last run's teleport can't
        // be taken for having arrived at this run's.
        LARGE_INTEGER counter;
        ::QueryPerformanceCounter(&counter);
        g_TeleportSequence = static_cast<std::uint32_t>(counter.QuadPart) | 0x100u;
        scriptRegister(p_Module, ScriptMain);
        break;
    }
    case DLL_PROCESS_DETACH:
        scriptUnregister(p_Module);
        break;
    }
    return TRUE;
}
