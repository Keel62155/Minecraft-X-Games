#pragma once

#include "Protocol.h"

#include <Windows.h>
#include <cstdint>
#include <functional>
#include <mutex>
#include <vector>

class HitCraftLink {
public:
    ~HitCraftLink();

    bool Create();
    bool Valid() const { return m_Base != nullptr; }
    bool MinecraftAlive() const;
    std::uint32_t MinecraftPid() const;
    void Heartbeat();
    void WriteHostState(const hitcraft::proto::SkyState& p_State);
    bool ReadMinecraftState(hitcraft::proto::McState& p_State) const;
    bool WriteCollision(hitcraft::proto::ColType p_Type, const void* p_Payload, std::uint32_t p_Bytes);
    void PushInput(hitcraft::proto::InputType p_Type, std::uint16_t p_Code, std::int32_t p_A = 0,
        std::int32_t p_B = 0, std::int32_t p_C = 0);
    void DrainRender(const std::function<void(std::uint32_t, const std::uint8_t*, std::uint32_t)>& p_Consumer,
        std::uint64_t p_MaxBytes);

    /** True if Minecraft has published an overlay frame we have not taken yet. */
    bool OverlayPending() const;
    /** Takes the newest overlay frame. The pixels stay valid until the next call. Single reader. */
    bool AcquireOverlay(const std::uint8_t*& p_Pixels, std::uint32_t& p_Width, std::uint32_t& p_Height,
        bool& p_BottomUp);
    /** The block Minecraft's crosshair is on, in Minecraft coordinates. */
    bool ReadSelection(float p_Min[3], float p_Max[3]) const;
    /** Minecraft things the host draws itself (dropped items, arrows). False on a torn read. */
    bool ReadWorldEntities(std::vector<hitcraft::proto::WorldEntity>& p_Out) const;
    /** Publishes the NPCs near the player (at most kMaxActors). */
    void WriteActors(const hitcraft::proto::ActorRecord* p_Actors, std::uint32_t p_Count);
    /** Takes every event Minecraft has queued (hits on NPCs, explosions). Single consumer. */
    void DrainEvents(const std::function<void(const hitcraft::proto::McEvent&)>& p_Consumer);

private:
    template <typename T>
    T* At(std::uint64_t p_Offset) const {
        return reinterpret_cast<T*>(m_Base + p_Offset);
    }

    HANDLE m_Mapping = nullptr;
    std::uint8_t* m_Base = nullptr;
    std::uint32_t m_OverlayFront = 2;
    std::mutex m_StateMutex;
    std::mutex m_InputMutex;
};
