# Third-party notices

- **SkyCraft** (https://github.com/chasmlol/SkyCraft), MIT License. `src/Protocol.h` mirrors
  SkyCraft's shared-memory protocol layout, and RedCraft talks to SkyCraft's unmodified Fabric mod.
  SkyCraft itself is not included.
- **Script Hook RDR2** by Alexander Blade (http://www.dev-c.com/rdr2/scripthookrdr2/). Required at
  run time and its SDK at build time. Neither is included: redistribution of the archive is not
  permitted by its author. Download it from the link above.

No license has been chosen for RedCraft's own source yet. Until one is added to this repository,
the default applies: you may read it, but ask before reusing it.