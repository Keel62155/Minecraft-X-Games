# RedCraft

Minecraft inside **Red Dead Redemption 2** (story mode). RedCraft is an ASI plugin for
[Script Hook RDR2](http://www.dev-c.com/rdr2/scripthookrdr2/). It plays the part that SkyCraft's
Skyrim plugin plays: SkyCraft's Minecraft runs hidden next to the game and the two talk over shared
memory. The game supplies the shape of the world; Minecraft supplies where the player is, its
physics, its blocks and its picture.

This is an experimental prototype. Expect rough edges.

## What it does

- **Player:** Minecraft is in charge of movement. The game's character is frozen, hidden and made
  invulnerable, and placed where the Minecraft player is every frame. Game controls are disabled
  while Minecraft drives (the pause menu still works).
- **Camera:** a script camera at the Minecraft player's eyes, turned with Minecraft's own mouse
  sensitivity. F5 gives Minecraft's third-person views with the Minecraft player model.
- **Collision:** the walkable surface around the player is flood-filled with ray casts, and
  everything in view is sampled with more rays; both are streamed to Minecraft so its physics walk on
  the game's world and blocks can be placed on it.
- **Picture:** Minecraft's blocks (textured, animated), entities, particles, dropped items, arrows,
  the player model, and Minecraft's own frame (hand, hotbar, inventory, chat) are drawn over the game.
- **World:** people and animals near the player are mirrored into Minecraft as hittable stand-ins.
  Hits take their health, Minecraft fire and lava set them alight, and Minecraft explosions (TNT)
  are real game explosions.

## Requirements

- Red Dead Redemption 2 on PC, **story mode only**. Script Hook closes the game if you go into
  Red Dead Online. Do not use this online.
- **Graphics API set to DirectX 12** (Settings > Graphics > Advanced). The game defaults to Vulkan,
  and RedCraft draws with DirectX 12: on Vulkan nothing of Minecraft is shown.
- [Script Hook RDR2](http://www.dev-c.com/rdr2/scripthookrdr2/) (`ScriptHookRDR2.dll` and its ASI
  loader `dinput8.dll`). It is not included here; its author does not allow redistribution.
- [SkyCraft](https://github.com/chasmlol/SkyCraft)'s bundled Minecraft, installed where SkyCraft puts
  it: `%LOCALAPPDATA%\SkyCraft\Prism` with an instance named `SkyCraft`. RedCraft starts
  `prismlauncher.exe --launch SkyCraft` from there and uses SkyCraft's Fabric mod unchanged.

## Installing

1. Install Script Hook RDR2 (copy `ScriptHookRDR2.dll` and `dinput8.dll` next to `RDR2.exe`).
2. Copy `RedCraft.asi` next to `RDR2.exe`.
3. Set Graphics API to DirectX 12 and restart the game.
4. Load a save where you control the character on foot. Minecraft starts by itself and needs about
   half a minute; its hotbar appears when it has taken over.

To uninstall, delete `RedCraft.asi`.

## Controls

| Key | Does |
|---|---|
| WASD, Space, Shift, Ctrl | Minecraft movement |
| Mouse, left / right click, wheel, 1-9 | Look, break, place, pick a hotbar slot |
| E, T, Q, F | Minecraft inventory, chat, drop, swap hands |
| F5 | Minecraft's third-person views |
| O | Minecraft's own menu |
| Esc | The game's pause menu |
| F10 | Hand the character back to the game, and back to Minecraft |

While you ride, drive or are in a cutscene, the game has the character and Minecraft waits.

## Known limitations

- **Arrows do not hurt characters yet**, and melee damage on characters is new and little tested.
- Blocks and entities are not hidden by the game's scenery (they show through walls).
- Characters do not hurt the Minecraft player.
- Collision is an approximation built from ray casts; you can still find holes.
- Only one host at a time: do not run it together with SkyCraft in Skyrim.

## Diagnostics

`%LOCALAPPDATA%\RedCraft\redcraft.log` is rewritten every run, with a status block every ten
seconds (including whether any DirectX 12 frames were seen).

## Building

Requirements: Visual Studio 2022 (C++ desktop workload) and CMake.

1. Download the Script Hook RDR2 **SDK** from its author's site and unpack it to
   `vendor/ScriptHookRDR2_SDK` (so that `vendor/ScriptHookRDR2_SDK/inc/main.h` exists).
2. From a "x64 Native Tools" prompt:

```
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

The result is `build/RedCraft.asi`.

## Layout

| File | What |
|---|---|
| `src/RedCraft.cpp` | The script: game natives, player, camera, input, characters, events |
| `src/Collision.*` | Flood-fill and view-ray collision scan, streamed as triangles and voxels |
| `src/Renderer.*` | DirectX 12 pass on the game's swap chain: blocks, entities, Minecraft's frame |
| `src/Link.*`, `src/Protocol.h` | SkyCraft's shared-memory protocol (v11), host side |

## Credits

See [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md). RedCraft is not affiliated with Rockstar Games,
Mojang or Microsoft.