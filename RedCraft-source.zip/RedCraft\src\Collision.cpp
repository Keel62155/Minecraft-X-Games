#include "Collision.h"

#include "Log.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
using Vec3 = HitCraftCollision::Vec3;

constexpr float kCell = 0.5f;          // grid spacing in metres (1 metre = 1 block)
constexpr float kRadius = 12.f;        // how far around the player the floor is explored
constexpr float kStep = 0.6f;          // Minecraft's step height
constexpr float kLevelTolerance = 0.7f; // two floors closer than this at one grid point are the same floor
constexpr float kDropLimit = 6.f;      // deeper drops than this are walled off instead of walked off
constexpr float kWallBelow = 0.25f;
constexpr float kWallAbove = 2.6f;
constexpr float kProbeHeights[] = { 0.55f, 1.0f, 1.5f };
constexpr int kDx[4] = { 1, -1, 0, 0 };
constexpr int kDy[4] = { 0, 0, 1, -1 };
constexpr std::size_t kMaxNodes = 30000;
constexpr int kVoxels = hitcraft::proto::kRegionSize * 8;

std::uint64_t GridKey(int p_Ix, int p_Iy) {
    return (std::uint64_t(std::uint32_t(p_Ix)) << 32) | std::uint32_t(p_Iy);
}

std::uint64_t RegionKey(int p_Rx, int p_Ry, int p_Rz) {
    constexpr std::uint64_t mask = (1ull << 21) - 1;
    return ((std::uint64_t(p_Rx) & mask) << 42) | ((std::uint64_t(p_Ry) & mask) << 21) | (std::uint64_t(p_Rz) & mask);
}

int FloorDiv(float p_Value, int p_Divisor) {
    return static_cast<int>(std::floor(p_Value / static_cast<float>(p_Divisor)));
}

double NowMs() {
    static const double frequency = [] {
        LARGE_INTEGER value;
        ::QueryPerformanceFrequency(&value);
        return static_cast<double>(value.QuadPart) / 1000.0;
    }();
    LARGE_INTEGER counter;
    ::QueryPerformanceCounter(&counter);
    return static_cast<double>(counter.QuadPart) / frequency;
}

std::uint64_t HashTriangle(const hitcraft::proto::ColTri& p_Triangle) {
    std::uint64_t hash = 1469598103934665603ull;
    const auto* bytes = reinterpret_cast<const std::uint8_t*>(&p_Triangle);
    for (std::size_t i = 0; i < sizeof(p_Triangle); ++i) {
        hash ^= bytes[i];
        hash *= 1099511628211ull;
    }
    hash ^= hash >> 29;
    return hash * 0x9E3779B97F4A7C15ull;
}

// The game is Z-up, Minecraft is Y-up with Z pointing south.
Vec3 ToMinecraft(const Vec3& p_Hitman) {
    return { p_Hitman.x, p_Hitman.z, -p_Hitman.y };
}

struct RegionBuild {
    int rx = 0, ry = 0, rz = 0;
    std::vector<hitcraft::proto::ColTri> triangles;
    std::uint64_t hash = 1;
};
}

void HitCraftCollision::Reset() {
    m_Nodes.clear();
    m_Grid.clear();
    m_Queue.clear();
    m_QueueHead = 0;
    m_CycleActive = false;
    m_Sent.clear();
    m_Static.clear();
    m_StaticDirty.clear();
    m_SurfelKeys.clear();
    m_SeedFailures = 0;
    m_Stats.cycles = 0;
    m_Stats.nodes = 0;
    m_Stats.triangles = 0;
    m_Stats.hasGround = false;
}

void HitCraftCollision::ForgetSent() {
    m_Sent.clear();
    for (const auto& [key, region] : m_Static)
        m_StaticDirty.insert(key);
}

void HitCraftCollision::AddSurfel(const Vec3& p_Position, const Vec3& p_Normal) {
    constexpr float size = 0.5f;
    float length = std::sqrt(p_Normal.x * p_Normal.x + p_Normal.y * p_Normal.y + p_Normal.z * p_Normal.z);
    if (length < 1e-4f)
        return;
    const Vec3 n { p_Normal.x / length, p_Normal.y / length, p_Normal.z / length };

    // One patch per half-metre cell and facing.
    const float ax = std::abs(n.x), ay = std::abs(n.y), az = std::abs(n.z);
    const int axis = ax >= ay && ax >= az ? (n.x > 0 ? 0 : 1) : ay >= az ? (n.y > 0 ? 2 : 3) : (n.z > 0 ? 4 : 5);
    const auto cell = [&](float p_Value) { return static_cast<std::uint64_t>(static_cast<std::int64_t>(std::floor(p_Value / size)) & 0xFFFFF); };
    const std::uint64_t key = (cell(p_Position.x) << 43) | (cell(p_Position.y) << 23) | (cell(p_Position.z) << 3) | static_cast<std::uint64_t>(axis);
    if (m_SurfelKeys.size() > 150000) {
        // A long trip across the city: start over rather than grow without bound.
        m_SurfelKeys.clear();
        m_Static.clear();
        m_StaticDirty.clear();
    }
    if (!m_SurfelKeys.insert(key).second)
        return;

    Vec3 t = az < 0.9f ? Vec3 { n.y, -n.x, 0.f } : Vec3 { 0.f, n.z, -n.y }; // n x up, or n x right
    length = std::sqrt(t.x * t.x + t.y * t.y + t.z * t.z);
    t = { t.x / length, t.y / length, t.z / length };
    const Vec3 b { n.y * t.z - n.z * t.y, n.z * t.x - n.x * t.z, n.x * t.y - n.y * t.x };
    constexpr float half = size * 0.6f; // patches overlap a little, so neighbours leave no gaps
    const auto corner = [&](float p_T, float p_B) {
        return ToMinecraft({ p_Position.x + (t.x * p_T + b.x * p_B) * half, p_Position.y + (t.y * p_T + b.y * p_B) * half,
            p_Position.z + (t.z * p_T + b.z * p_B) * half });
    };
    const Vec3 normal = ToMinecraft(n);
    const Vec3 corners[4] = { corner(-1.f, -1.f), corner(1.f, -1.f), corner(1.f, 1.f), corner(-1.f, 1.f) };
    const int order[2][3] = { { 0, 1, 2 }, { 0, 2, 3 } };
    for (const auto& indices : order) {
        Vec3 a = corners[indices[0]], bb = corners[indices[1]], c = corners[indices[2]];
        const Vec3 e1 { bb.x - a.x, bb.y - a.y, bb.z - a.z }, e2 { c.x - a.x, c.y - a.y, c.z - a.z };
        const Vec3 cross { e1.y * e2.z - e1.z * e2.y, e1.z * e2.x - e1.x * e2.z, e1.x * e2.y - e1.y * e2.x };
        if (cross.x * normal.x + cross.y * normal.y + cross.z * normal.z < 0.f)
            std::swap(bb, c);
        hitcraft::proto::ColTri triangle {};
        const float values[9] = { a.x, a.y, a.z, bb.x, bb.y, bb.z, c.x, c.y, c.z };
        std::memcpy(triangle.v, values, sizeof(values));
        const std::uint64_t hash = HashTriangle(triangle);

        constexpr int regionSize = hitcraft::proto::kRegionSize;
        constexpr float margin = 0.5f;
        const int rx0 = FloorDiv(std::min({ a.x, bb.x, c.x }) - margin, regionSize), rx1 = FloorDiv(std::max({ a.x, bb.x, c.x }) + margin, regionSize);
        const int ry0 = FloorDiv(std::min({ a.y, bb.y, c.y }) - margin, regionSize), ry1 = FloorDiv(std::max({ a.y, bb.y, c.y }) + margin, regionSize);
        const int rz0 = FloorDiv(std::min({ a.z, bb.z, c.z }) - margin, regionSize), rz1 = FloorDiv(std::max({ a.z, bb.z, c.z }) + margin, regionSize);
        for (int rx = rx0; rx <= rx1; ++rx) {
            for (int ry = ry0; ry <= ry1; ++ry) {
                for (int rz = rz0; rz <= rz1; ++rz) {
                    const std::uint64_t regionKey = RegionKey(rx, ry, rz);
                    auto& region = m_Static[regionKey];
                    region.rx = rx;
                    region.ry = ry;
                    region.rz = rz;
                    region.triangles.push_back(triangle);
                    region.hash += hash;
                    m_StaticDirty.insert(regionKey);
                }
            }
        }
    }
}

bool HitCraftCollision::Cast(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit) {
    if (!m_Raycaster)
        return false;

    ++m_Stats.rays;
    ++m_RaysThisFrame;
    Vec3 hit;
    if (!m_Raycaster(p_From, p_To, hit))
        return false;

    // Reject anything that is not on the segment (an unset output, for one).
    constexpr float slack = 0.25f;
    if (hit.x < std::min(p_From.x, p_To.x) - slack || hit.x > std::max(p_From.x, p_To.x) + slack ||
        hit.y < std::min(p_From.y, p_To.y) - slack || hit.y > std::max(p_From.y, p_To.y) + slack ||
        hit.z < std::min(p_From.z, p_To.z) - slack || hit.z > std::max(p_From.z, p_To.z) + slack)
        return false;

    ++m_Stats.hits;
    p_Hit = hit;
    return true;
}
bool HitCraftCollision::CastFloor(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit) {
    if (Cast(p_From, p_To, p_Hit))
        return true;
    // A hit right at the start of the ray is the thing the ray started inside, not a floor.
    return m_FloorFallback && m_FloorFallback(p_From, p_To, p_Hit) && p_Hit.z < p_From.z - 0.25f && p_Hit.z >= p_To.z - 0.25f;
}

int HitCraftCollision::FindNode(int p_Ix, int p_Iy, float p_Z, float p_Tolerance) const {
    const auto found = m_Grid.find(GridKey(p_Ix, p_Iy));
    if (found == m_Grid.end())
        return -1;
    int best = -1;
    float bestDistance = p_Tolerance;
    for (const int index : found->second) {
        const float distance = std::abs(m_Nodes[index].z - p_Z);
        if (distance <= bestDistance) {
            bestDistance = distance;
            best = index;
        }
    }
    return best;
}

int HitCraftCollision::AddNode(int p_Ix, int p_Iy, float p_Z) {
    Node node;
    node.ix = p_Ix;
    node.iy = p_Iy;
    node.z = p_Z;
    m_Nodes.push_back(node);
    const int index = static_cast<int>(m_Nodes.size()) - 1;
    m_Grid[GridKey(p_Ix, p_Iy)].push_back(index);
    return index;
}

void HitCraftCollision::Visit(int p_Node) {
    if (m_Nodes[p_Node].stamp == m_Stamp)
        return;
    m_Nodes[p_Node].stamp = m_Stamp;
    m_Queue.push_back(p_Node);
}

bool HitCraftCollision::BeginCycle(const Vec3& p_Player) {
    ++m_Stamp;
    m_Queue.clear();
    m_QueueHead = 0;
    m_Center = p_Player;

    const int baseX = static_cast<int>(std::floor(p_Player.x / kCell));
    const int baseY = static_cast<int>(std::floor(p_Player.y / kCell));
    for (int oy = 0; oy <= 1; ++oy) {
        for (int ox = 0; ox <= 1; ++ox) {
            const int ix = baseX + ox, iy = baseY + oy;
            const Vec3 from { ix * kCell, iy * kCell, p_Player.z + 1.0f };
            const Vec3 to { from.x, from.y, p_Player.z - 80.f };
            Vec3 hit;
            if (!CastFloor(from, to, hit))
                continue;
            int node = FindNode(ix, iy, hit.z, kLevelTolerance);
            if (node < 0)
                node = AddNode(ix, iy, hit.z);
            Visit(node);
        }
    }

    m_Stats.hasGround = !m_Queue.empty();
    if (m_Queue.empty()) {
        // Nothing under the player. If "static only" finds no ground at all, this build of the
        // engine classifies level geometry differently: fall back to everything.
        if (++m_SeedFailures == 60 && m_Stats.staticOnly && m_Stats.hits == 0) {
            m_Stats.staticOnly = false;
            HcLog("collision: static-only ray casts never hit anything; switching to static + dynamic");
        }
        return false;
    }
    m_SeedFailures = 0;
    m_CycleActive = true;
    return true;
}

void HitCraftCollision::ScanNode(int p_Node, double p_Now) {
    for (int direction = 0; direction < 4; ++direction) {
        const int ix = m_Nodes[p_Node].ix, iy = m_Nodes[p_Node].iy;
        const float z = m_Nodes[p_Node].z;

        // The neighbour already looked this way a moment ago and found it open: keep that.
        const int known = m_Nodes[p_Node].next[direction];
        if (m_Nodes[p_Node].edge[direction] == kOpen && known >= 0) {
            const Node& other = m_Nodes[known];
            if (other.scannedAt > 0.0 && p_Now - other.scannedAt < 2000.0 && other.edge[direction ^ 1] == kOpen &&
                other.next[direction ^ 1] == p_Node)
                continue;
        }

        const int bx = ix + kDx[direction], by = iy + kDy[direction];
        const Vec3 a { ix * kCell, iy * kCell, z };
        const Vec3 b { bx * kCell, by * kCell, z };

        bool blocked = false;
        float wall = kCell;
        for (const float height : kProbeHeights) {
            Vec3 hit;
            if (Cast({ a.x, a.y, z + height }, { b.x, b.y, z + height }, hit)) {
                blocked = true;
                wall = std::min(wall, std::hypot(hit.x - a.x, hit.y - a.y));
            }
        }

        if (!blocked) {
            Vec3 ground;
            if (!CastFloor({ b.x, b.y, z + 1.2f }, { b.x, b.y, z - kDropLimit }, ground) || ground.z > z + kStep + 0.02f) {
                // A bottomless drop (or something only a ray from above can see): wall it off.
                blocked = true;
                wall = kCell * 0.5f;
            } else {
                int other = FindNode(bx, by, ground.z, kLevelTolerance);
                if (other < 0)
                    other = AddNode(bx, by, ground.z);
                else if (std::abs(m_Nodes[other].z - ground.z) > 0.05f)
                    m_Nodes[other].z = ground.z;
                m_Nodes[p_Node].edge[direction] = kOpen;
                m_Nodes[p_Node].next[direction] = other;
                if (m_Nodes[other].edge[direction ^ 1] != kBlocked) {
                    m_Nodes[other].edge[direction ^ 1] = kOpen;
                    m_Nodes[other].next[direction ^ 1] = p_Node;
                }
            }
        }

        if (blocked) {
            m_Nodes[p_Node].edge[direction] = kBlocked;
            m_Nodes[p_Node].next[direction] = -1;
            m_Nodes[p_Node].wall[direction] = std::clamp(wall, 0.05f, kCell);
        }
    }
    m_Nodes[p_Node].scannedAt = p_Now;
}

void HitCraftCollision::Update(HitCraftLink& p_Link, std::uint32_t p_Epoch, const Vec3& p_Player, bool p_CanSend) {
    m_RaysThisFrame = 0;
    if (!m_Raycaster)
        return;

    const double start = NowMs();
    if (!m_CycleActive) {
        if (m_Stats.cycles > 0 && start - m_LastCycleEnd < 200.0) {
            m_Stats.raysLastFrame = 0;
            return;
        }
        if (m_Nodes.size() > kMaxNodes) {
            m_Nodes.clear();
            m_Grid.clear();
        }
        if (!BeginCycle(p_Player)) {
            // Nothing under the player (high in the air, or over a void). Minecraft still has to be
            // told the regions around it are known, or it keeps the player frozen forever.
            if (p_CanSend && start - m_LastCycleEnd > 500.0) {
                BuildAndSend(p_Link, p_Epoch, true, true);
                m_LastCycleEnd = start;
            }
            m_Stats.raysLastFrame = m_RaysThisFrame;
            return;
        }
        m_CycleStart = start;
    }

    // The very first scan decides how long Minecraft holds the player frozen, so it gets more time.
    const double budget = m_Stats.cycles == 0 ? 6.0 : 1.5;
    while (m_QueueHead < m_Queue.size()) {
        const double now = NowMs();
        if (now - start > budget)
            break;
        const int index = m_Queue[m_QueueHead++];
        const float dx = m_Nodes[index].ix * kCell - m_Center.x;
        const float dy = m_Nodes[index].iy * kCell - m_Center.y;
        const float distanceSq = dx * dx + dy * dy;
        if (distanceSq > kRadius * kRadius)
            continue;
        const double lifetime = distanceSq < 36.f ? 4000.0 : 30000.0;
        if (m_Nodes[index].scannedAt == 0.0 || now - m_Nodes[index].scannedAt > lifetime)
            ScanNode(index, now);
        for (int direction = 0; direction < 4; ++direction) {
            if (m_Nodes[index].edge[direction] == kOpen && m_Nodes[index].next[direction] >= 0)
                Visit(m_Nodes[index].next[direction]);
        }
    }

    if (m_QueueHead >= m_Queue.size()) {
        m_CycleActive = false;
        BuildAndSend(p_Link, p_Epoch, p_CanSend, false);
        m_LastCycleEnd = NowMs();
        m_Stats.cycleMs = static_cast<float>(m_LastCycleEnd - m_CycleStart);
        if (m_Stats.cycles++ == 0) {
            HcLog("collision: first scan done: %zu floor points, %u triangles, %llu rays (%llu hits), %.0f ms, %s",
                m_Queue.size(), m_Stats.triangles, m_Stats.rays, m_Stats.hits, m_Stats.cycleMs,
                m_Stats.staticOnly ? "static only" : "static + dynamic");
        }
    }
    m_Stats.raysLastFrame = m_RaysThisFrame;
    m_Stats.nodes = static_cast<std::uint32_t>(m_Nodes.size());
}

int HitCraftCollision::OpenNeighbor(int p_Node, int p_Direction) const {
    const Node& node = m_Nodes[p_Node];
    if (node.edge[p_Direction] != kOpen || node.next[p_Direction] < 0)
        return -1;
    const Node& other = m_Nodes[node.next[p_Direction]];
    if (other.stamp != m_Stamp || std::abs(other.z - node.z) > kStep)
        return -1;
    return node.next[p_Direction];
}

void HitCraftCollision::BuildAndSend(HitCraftLink& p_Link, std::uint32_t p_Epoch, bool p_CanSend, bool p_OnlyUnknown) {
    std::unordered_map<std::uint64_t, RegionBuild> regions;
    std::uint32_t triangleCount = 0;

    // p_Normal is the side the open space is on; Minecraft wants the winding to face it.
    const auto addTriangle = [&](const Vec3& p_A, const Vec3& p_B, const Vec3& p_C, const Vec3& p_Normal) {
        const Vec3 a = ToMinecraft(p_A);
        Vec3 b = ToMinecraft(p_B), c = ToMinecraft(p_C);
        const Vec3 normal = ToMinecraft(p_Normal);
        const Vec3 e1 { b.x - a.x, b.y - a.y, b.z - a.z }, e2 { c.x - a.x, c.y - a.y, c.z - a.z };
        const Vec3 cross { e1.y * e2.z - e1.z * e2.y, e1.z * e2.x - e1.x * e2.z, e1.x * e2.y - e1.y * e2.x };
        if (cross.x * normal.x + cross.y * normal.y + cross.z * normal.z < 0.f)
            std::swap(b, c);

        hitcraft::proto::ColTri triangle {};
        const float values[9] = { a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z };
        std::memcpy(triangle.v, values, sizeof(values));
        const std::uint64_t hash = HashTriangle(triangle);
        ++triangleCount;

        constexpr int size = hitcraft::proto::kRegionSize;
        constexpr float margin = 0.5f;
        const int rx0 = FloorDiv(std::min({ a.x, b.x, c.x }) - margin, size), rx1 = FloorDiv(std::max({ a.x, b.x, c.x }) + margin, size);
        const int ry0 = FloorDiv(std::min({ a.y, b.y, c.y }) - margin, size), ry1 = FloorDiv(std::max({ a.y, b.y, c.y }) + margin, size);
        const int rz0 = FloorDiv(std::min({ a.z, b.z, c.z }) - margin, size), rz1 = FloorDiv(std::max({ a.z, b.z, c.z }) + margin, size);
        for (int rx = rx0; rx <= rx1; ++rx) {
            for (int ry = ry0; ry <= ry1; ++ry) {
                for (int rz = rz0; rz <= rz1; ++rz) {
                    auto& region = regions[RegionKey(rx, ry, rz)];
                    region.rx = rx;
                    region.ry = ry;
                    region.rz = rz;
                    region.triangles.push_back(triangle);
                    region.hash += hash; // order-independent
                }
            }
        }
    };

    const Vec3 up { 0.f, 0.f, 1.f };
    const auto position = [&](int p_Node) {
        const Node& node = m_Nodes[p_Node];
        return Vec3 { node.ix * kCell, node.iy * kCell, node.z };
    };

    for (const int index : m_Queue)
        m_Nodes[index].cells = 0;

    // Floor: a quad per grid cell whose four corners are on the same walkable surface.
    for (const int a : m_Queue) {
        const int b = OpenNeighbor(a, 0);
        const int c = OpenNeighbor(a, 2);
        if (b < 0 || c < 0)
            continue;
        int d = OpenNeighbor(b, 2);
        if (d < 0)
            d = OpenNeighbor(c, 0);
        if (d < 0)
            continue;
        addTriangle(position(a), position(b), position(d), up);
        addTriangle(position(a), position(d), position(c), up);
        m_Nodes[a].cells |= 1;
        m_Nodes[b].cells |= 2;
        m_Nodes[c].cells |= 4;
        m_Nodes[d].cells |= 8;
    }

    for (const int index : m_Queue) {
        const Node node = m_Nodes[index];
        const Vec3 centre = position(index);

        // Along walls and ledges the cells are incomplete: a flat pad keeps the floor under the
        // player right up to the wall.
        if (node.cells != 0xF) {
            constexpr float half = kCell * 0.5f;
            const Vec3 p00 { centre.x - half, centre.y - half, centre.z }, p10 { centre.x + half, centre.y - half, centre.z };
            const Vec3 p01 { centre.x - half, centre.y + half, centre.z }, p11 { centre.x + half, centre.y + half, centre.z };
            addTriangle(p00, p10, p11, up);
            addTriangle(p00, p11, p01, up);
        }

        for (int direction = 0; direction < 4; ++direction) {
            const Vec3 forward { static_cast<float>(kDx[direction]), static_cast<float>(kDy[direction]), 0.f };
            const Vec3 side { -forward.y, forward.x, 0.f };
            constexpr float half = kCell * 0.5f + 0.02f;

            float distance = 0.f, bottom = 0.f, top = 0.f;
            Vec3 facing;
            if (node.edge[direction] == kBlocked) {
                distance = node.wall[direction];
                bottom = node.z - kWallBelow;
                top = node.z + kWallAbove;
                facing = { -forward.x, -forward.y, 0.f };
            } else if (node.edge[direction] == kOpen && node.next[direction] >= 0 &&
                m_Nodes[node.next[direction]].stamp == m_Stamp && node.z - m_Nodes[node.next[direction]].z > kStep) {
                // A ledge: the face of the drop, seen from below.
                distance = kCell * 0.5f;
                bottom = m_Nodes[node.next[direction]].z - 0.05f;
                top = node.z;
                facing = forward;
            } else {
                continue;
            }

            const Vec3 base { centre.x + forward.x * distance, centre.y + forward.y * distance, 0.f };
            const Vec3 p0 { base.x - side.x * half, base.y - side.y * half, bottom };
            const Vec3 p1 { base.x + side.x * half, base.y + side.y * half, bottom };
            const Vec3 p2 { base.x - side.x * half, base.y - side.y * half, top };
            const Vec3 p3 { base.x + side.x * half, base.y + side.y * half, top };
            addTriangle(p0, p1, p3, facing);
            addTriangle(p0, p3, p2, facing);
        }
    }

    if (!p_OnlyUnknown)
        m_Stats.triangles = triangleCount;
    if (!p_CanSend)
        return;

    // Minecraft keeps the player frozen until the regions around and below the feet are known,
    // so those are always sent, even when they are empty.
    const Vec3 player = ToMinecraft(m_Center);
    constexpr int size = hitcraft::proto::kRegionSize;
    const int prx = FloorDiv(player.x, size), pry = FloorDiv(player.y, size), prz = FloorDiv(player.z, size);
    for (int rx = prx - 2; rx <= prx + 2; ++rx) {
        for (int ry = pry - 2; ry <= pry + 1; ++ry) {
            for (int rz = prz - 2; rz <= prz + 2; ++rz) {
                auto& region = regions[RegionKey(rx, ry, rz)];
                region.rx = rx;
                region.ry = ry;
                region.rz = rz;
            }
        }
    }

    // Regions that gained view-ray patches since last time are sent too, wherever they are.
    for (const std::uint64_t key : m_StaticDirty) {
        const auto found = m_Static.find(key);
        if (found == m_Static.end())
            continue;
        auto& region = regions[key];
        region.rx = found->second.rx;
        region.ry = found->second.ry;
        region.rz = found->second.rz;
    }

    // What has to go out, nearest first, and only so much per pass: sending a region means
    // voxelizing it here and rebuilding it in Minecraft, and view rays keep touching many of them.
    struct Pending {
        std::uint64_t key, hash;
        int distance;
    };
    std::vector<Pending> pending;
    for (const auto& [key, region] : regions) {
        const auto patches = m_Static.find(key);
        const std::uint64_t hash = region.hash + (patches != m_Static.end() ? patches->second.hash : 0);
        const auto sent = m_Sent.find(key);
        if (sent != m_Sent.end() && sent->second == hash) {
            m_StaticDirty.erase(key);
            continue;
        }
        if (sent != m_Sent.end() && p_OnlyUnknown && m_StaticDirty.find(key) == m_StaticDirty.end())
            continue;
        const int distance = std::max({ std::abs(region.rx - prx), std::abs(region.ry - pry), std::abs(region.rz - prz) });
        pending.push_back({ key, hash, distance });
    }
    std::sort(pending.begin(), pending.end(), [](const Pending& p_A, const Pending& p_B) { return p_A.distance < p_B.distance; });

    constexpr std::size_t kMaxPerPass = 40;
    std::vector<hitcraft::proto::ColTri> combined;
    std::size_t sentNow = 0;
    for (const auto& item : pending) {
        // Everything right around the player always goes; the rest waits its turn.
        if (sentNow >= kMaxPerPass && item.distance > 2)
            break;
        const auto& region = regions[item.key];
        const auto patches = m_Static.find(item.key);
        const std::vector<hitcraft::proto::ColTri>* triangles = &region.triangles;
        if (patches != m_Static.end()) {
            combined = region.triangles;
            combined.insert(combined.end(), patches->second.triangles.begin(), patches->second.triangles.end());
            triangles = &combined;
        }
        if (!SendRegion(p_Link, p_Epoch, region.rx, region.ry, region.rz, *triangles))
            break; // ring full: Minecraft is behind; the rest goes next cycle
        m_Sent[item.key] = item.hash;
        m_StaticDirty.erase(item.key);
        ++m_Stats.regionsSent;
        ++sentNow;
    }
}
bool HitCraftCollision::SendRegion(HitCraftLink& p_Link, std::uint32_t p_Epoch, int p_Rx, int p_Ry, int p_Rz,
    const std::vector<hitcraft::proto::ColTri>& p_Triangles) {
    using namespace hitcraft::proto;

    ColRegion header {};
    header.minX = p_Rx * kRegionSize;
    header.minY = p_Ry * kRegionSize;
    header.minZ = p_Rz * kRegionSize;
    header.maxX = header.minX + kRegionSize - 1;
    header.maxY = header.minY + kRegionSize - 1;
    header.maxZ = header.minZ + kRegionSize - 1;
    header.epoch = p_Epoch;

    // Exact triangles first (the player's collider and the crosshair pick use these)...
    header.count = static_cast<std::uint32_t>(p_Triangles.size());
    std::vector<std::uint8_t> payload(sizeof(header) + p_Triangles.size() * sizeof(ColTri));
    std::memcpy(payload.data(), &header, sizeof(header));
    if (!p_Triangles.empty())
        std::memcpy(payload.data() + sizeof(header), p_Triangles.data(), p_Triangles.size() * sizeof(ColTri));
    if (!p_Link.WriteCollision(kColTris, payload.data(), static_cast<std::uint32_t>(payload.size())))
        return false;

    // ...then the same surfaces as 1/8-block voxels, for everything else in Minecraft (dropped
    // items, arrows, mobs, "is there ground here").
    std::vector<std::uint64_t> grid(static_cast<std::size_t>(kVoxels) * kVoxels, 0); // [y * kVoxels + z], bit x
    const auto set = [&](int p_X, int p_Y, int p_Z) {
        if (p_X >= 0 && p_Y >= 0 && p_Z >= 0 && p_X < kVoxels && p_Y < kVoxels && p_Z < kVoxels)
            grid[static_cast<std::size_t>(p_Y) * kVoxels + p_Z] |= 1ull << p_X;
    };
    const float ox = static_cast<float>(header.minX), oy = static_cast<float>(header.minY), oz = static_cast<float>(header.minZ);
    for (const auto& triangle : p_Triangles) {
        const float* v = triangle.v;
        const float a[3] = { (v[0] - ox) * 8.f, (v[1] - oy) * 8.f, (v[2] - oz) * 8.f };
        const float e1[3] = { (v[3] - v[0]) * 8.f, (v[4] - v[1]) * 8.f, (v[5] - v[2]) * 8.f };
        const float e2[3] = { (v[6] - v[0]) * 8.f, (v[7] - v[1]) * 8.f, (v[8] - v[2]) * 8.f };
        const float nx = e1[1] * e2[2] - e1[2] * e2[1], ny = e1[2] * e2[0] - e1[0] * e2[2], nz = e1[0] * e2[1] - e1[1] * e2[0];
        const float length = std::sqrt(nx * nx + ny * ny + nz * nz);
        const bool floorLike = length > 0.f && std::abs(ny) / length > 0.7f;
        const int n1 = std::max(1, static_cast<int>(std::ceil(std::sqrt(e1[0] * e1[0] + e1[1] * e1[1] + e1[2] * e1[2]) * 2.f)));
        const int n2 = std::max(1, static_cast<int>(std::ceil(std::sqrt(e2[0] * e2[0] + e2[1] * e2[1] + e2[2] * e2[2]) * 2.f)));
        for (int i = 0; i <= n1; ++i) {
            const float s = static_cast<float>(i) / n1;
            for (int j = 0; j <= n2; ++j) {
                const float t = static_cast<float>(j) / n2;
                if (s + t > 1.0001f)
                    break;
                const int x = static_cast<int>(std::floor(a[0] + e1[0] * s + e2[0] * t));
                const int y = static_cast<int>(std::floor(a[1] + e1[1] * s + e2[1] * t - 0.01f));
                const int z = static_cast<int>(std::floor(a[2] + e1[2] * s + e2[2] * t));
                set(x, y, z);
                if (floorLike)
                    set(x, y - 1, z); // a floor one voxel thin is easy to fall through
            }
        }
    }

    std::vector<ColBlock> blocks;
    for (int by = 0; by < kRegionSize; ++by) {
        for (int bz = 0; bz < kRegionSize; ++bz) {
            for (int bx = 0; bx < kRegionSize; ++bx) {
                ColBlock block {};
                bool any = false;
                for (int sy = 0; sy < 8; ++sy) {
                    std::uint64_t layer = 0;
                    for (int sz = 0; sz < 8; ++sz) {
                        const std::uint64_t row = (grid[static_cast<std::size_t>(by * 8 + sy) * kVoxels + (bz * 8 + sz)] >> (bx * 8)) & 0xFF;
                        layer |= row << (sz * 8);
                    }
                    block.bits[sy] = layer;
                    any |= layer != 0;
                }
                if (!any)
                    continue;
                block.x = header.minX + bx;
                block.y = header.minY + by;
                block.z = header.minZ + bz;
                blocks.push_back(block);
            }
        }
    }

    header.count = static_cast<std::uint32_t>(blocks.size());
    payload.assign(sizeof(header) + blocks.size() * sizeof(ColBlock), 0);
    std::memcpy(payload.data(), &header, sizeof(header));
    if (!blocks.empty())
        std::memcpy(payload.data() + sizeof(header), blocks.data(), blocks.size() * sizeof(ColBlock));
    return p_Link.WriteCollision(kColRegion, payload.data(), static_cast<std::uint32_t>(payload.size()));
}
