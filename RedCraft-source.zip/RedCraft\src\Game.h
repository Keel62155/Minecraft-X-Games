#pragma once

#include "Collision.h"

/** The few types the renderer shares with the game side. Coordinates are the game's (metres, Z up). */
namespace Game {
using Vec3 = HitCraftCollision::Vec3;

struct Camera {
    Vec3 position, forward, right, up;
    // clip.x = scaleX * (p . right) / (p . forward), likewise y with up. scaleX 0 = derive it from
    // scaleY and the picture's aspect ratio.
    float scaleX = 0.f, scaleY = 1.428f;
};
}
