#include "Link.h"

#include "Log.h"

#include <atomic>
#include <cstring>
#include <intrin.h>

namespace {
template <typename T>
std::atomic_ref<T> Atomic(T& p_Value) {
    return std::atomic_ref<T>(p_Value);
}
}

HitCraftLink::~HitCraftLink() {
    if (m_Base)
        ::UnmapViewOfFile(m_Base);
    if (m_Mapping)
        ::CloseHandle(m_Mapping);
}

bool HitCraftLink::Create() {
    if (m_Base)
        return true;

    const auto size = hitcraft::proto::kMappingBytes;
    m_Mapping = ::CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE,
        static_cast<DWORD>(size >> 32), static_cast<DWORD>(size), hitcraft::proto::kMappingName);
    if (!m_Mapping) {
        HcLog("CreateFileMapping failed: %lu", ::GetLastError());
        return false;
    }

    m_Base = static_cast<std::uint8_t*>(::MapViewOfFile(m_Mapping, FILE_MAP_ALL_ACCESS, 0, 0, 0));
    if (!m_Base) {
        HcLog("MapViewOfFile failed: %lu", ::GetLastError());
        ::CloseHandle(m_Mapping);
        m_Mapping = nullptr;
        return false;
    }

    std::memset(m_Base + hitcraft::proto::kOffSkyState, 0, sizeof(hitcraft::proto::SkyState));
    std::memset(m_Base + hitcraft::proto::kOffMcState, 0, sizeof(hitcraft::proto::McState));
    std::memset(m_Base + hitcraft::proto::kOffOverlayCtl, 0, 0x100);
    // A zero sequence number tells Minecraft there is no host water at all.
    std::memset(m_Base + hitcraft::proto::kOffWaterGrid, 0, hitcraft::proto::kWaterGridBytes);
    m_OverlayFront = 2;
    std::memset(m_Base + hitcraft::proto::kOffInputRing, 0, 0x80);
    std::memset(m_Base + hitcraft::proto::kOffActorTable, 0, 0x40);
    std::memset(m_Base + hitcraft::proto::kOffEventRing, 0, 0x80);
    std::memset(m_Base + hitcraft::proto::kOffWorldEntities, 0, 0x40);
    std::memset(m_Base + hitcraft::proto::kOffCollisionRing, 0, hitcraft::proto::kColRingDataOff);
    std::memset(m_Base + hitcraft::proto::kOffRenderRing, 0, 0x80);

    auto* header = At<hitcraft::proto::Header>(hitcraft::proto::kOffHeader);
    header->version = hitcraft::proto::kVersion;
    header->skyrimPid = ::GetCurrentProcessId();
    header->skyrimHeartbeatMs = ::GetTickCount64();
    Atomic(header->magic).store(hitcraft::proto::kMagic, std::memory_order_release);
    HcLog("SkyCraft v11 shared-memory bridge created");
    return true;
}

bool HitCraftLink::MinecraftAlive() const {
    if (!m_Base)
        return false;
    auto& value = At<hitcraft::proto::Header>(hitcraft::proto::kOffHeader)->mcHeartbeatMs;
    const auto beat = Atomic(value).load(std::memory_order_acquire);
    // Generous: Minecraft stalls for seconds while it opens its world, and that is not "gone".
    return beat != 0 && ::GetTickCount64() - beat < 8000;
}

std::uint32_t HitCraftLink::MinecraftPid() const {
    if (!m_Base)
        return 0;
    auto& value = At<hitcraft::proto::Header>(hitcraft::proto::kOffHeader)->mcPid;
    return Atomic(value).load(std::memory_order_acquire);
}

void HitCraftLink::Heartbeat() {
    if (!m_Base)
        return;
    auto& value = At<hitcraft::proto::Header>(hitcraft::proto::kOffHeader)->skyrimHeartbeatMs;
    Atomic(value).store(::GetTickCount64(), std::memory_order_release);
}

void HitCraftLink::WriteHostState(const hitcraft::proto::SkyState& p_State) {
    if (!m_Base)
        return;
    // The game thread and the render thread (while the game is paused) both publish state.
    std::scoped_lock lock(m_StateMutex);
    auto* destination = At<hitcraft::proto::SkyState>(hitcraft::proto::kOffSkyState);
    auto seq = Atomic(destination->seq);
    const auto current = seq.load(std::memory_order_relaxed);
    seq.store(current + 1, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_release);
    std::memcpy(reinterpret_cast<std::uint8_t*>(destination) + 4,
        reinterpret_cast<const std::uint8_t*>(&p_State) + 4, sizeof(p_State) - 4);
    seq.store(current + 2, std::memory_order_release);
}

bool HitCraftLink::ReadMinecraftState(hitcraft::proto::McState& p_State) const {
    if (!m_Base)
        return false;
    auto* source = At<hitcraft::proto::McState>(hitcraft::proto::kOffMcState);
    auto seq = Atomic(source->seq);
    for (int attempt = 0; attempt < 64; ++attempt) {
        const auto first = seq.load(std::memory_order_acquire);
        if (first & 1) {
            _mm_pause();
            continue;
        }
        std::memcpy(&p_State, source, sizeof(p_State));
        std::atomic_thread_fence(std::memory_order_acquire);
        if (seq.load(std::memory_order_relaxed) == first)
            return true;
    }
    return false;
}

bool HitCraftLink::WriteCollision(hitcraft::proto::ColType p_Type, const void* p_Payload, std::uint32_t p_Bytes) {
    if (!m_Base)
        return false;
    auto* ring = m_Base + hitcraft::proto::kOffCollisionRing;
    auto& headValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kColRingHeadOff);
    auto& tailValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kColRingTailOff);
    auto* data = ring + hitcraft::proto::kColRingDataOff;
    constexpr auto size = hitcraft::proto::kColRingDataBytes;
    const std::uint64_t messageBytes = (sizeof(hitcraft::proto::ColMsgHeader) + p_Bytes + 7) & ~7ull;
    if (messageBytes > size / 2)
        return false;
    auto head = Atomic(headValue).load(std::memory_order_relaxed);
    const auto tail = Atomic(tailValue).load(std::memory_order_acquire);
    auto position = head % size;
    const auto padding = position + messageBytes > size ? size - position : 0;
    if (size - (head - tail) < messageBytes + padding)
        return false;
    if (padding) {
        *reinterpret_cast<hitcraft::proto::ColMsgHeader*>(data + position) = { hitcraft::proto::kColPad, 0 };
        head += padding;
        position = 0;
    }
    *reinterpret_cast<hitcraft::proto::ColMsgHeader*>(data + position) = { p_Type, p_Bytes };
    std::memcpy(data + position + sizeof(hitcraft::proto::ColMsgHeader), p_Payload, p_Bytes);
    Atomic(headValue).store(head + messageBytes, std::memory_order_release);
    return true;
}

void HitCraftLink::PushInput(hitcraft::proto::InputType p_Type, std::uint16_t p_Code,
    std::int32_t p_A, std::int32_t p_B, std::int32_t p_C) {
    if (!m_Base)
        return;
    std::scoped_lock lock(m_InputMutex);
    auto* ring = m_Base + hitcraft::proto::kOffInputRing;
    auto& headValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kInputRingHeadOff);
    auto& tailValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kInputRingTailOff);
    const auto head = Atomic(headValue).load(std::memory_order_relaxed);
    const auto tail = Atomic(tailValue).load(std::memory_order_acquire);
    if (head - tail >= hitcraft::proto::kInputRingEntries)
        return;
    auto* entry = reinterpret_cast<hitcraft::proto::InputEvent*>(ring + hitcraft::proto::kInputRingDataOff) +
        (head & (hitcraft::proto::kInputRingEntries - 1));
    *entry = { static_cast<std::uint16_t>(p_Type), p_Code, p_A, p_B, p_C };
    Atomic(headValue).store(head + 1, std::memory_order_release);
}

void HitCraftLink::DrainRender(
    const std::function<void(std::uint32_t, const std::uint8_t*, std::uint32_t)>& p_Consumer,
    std::uint64_t p_MaxBytes) {
    if (!m_Base)
        return;
    auto* ring = m_Base + hitcraft::proto::kOffRenderRing;
    auto& headValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kRenRingHeadOff);
    auto& tailValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kRenRingTailOff);
    const auto head = Atomic(headValue).load(std::memory_order_acquire);
    auto tail = Atomic(tailValue).load(std::memory_order_relaxed);
    auto* data = ring + hitcraft::proto::kRenRingDataOff;
    constexpr auto size = hitcraft::proto::kRenRingDataBytes;
    std::uint64_t consumed = 0;
    while (tail < head && consumed < p_MaxBytes) {
        const auto position = tail % size;
        const auto* header = reinterpret_cast<const hitcraft::proto::ColMsgHeader*>(data + position);
        if (header->type == hitcraft::proto::kRenPad) {
            tail += size - position;
            continue;
        }
        if (header->payloadBytes > size - sizeof(*header))
            break;
        p_Consumer(header->type, data + position + sizeof(*header), header->payloadBytes);
        const auto messageBytes = (sizeof(*header) + header->payloadBytes + 7) & ~7ull;
        tail += messageBytes;
        consumed += messageBytes;
    }
    Atomic(tailValue).store(tail, std::memory_order_release);
}

bool HitCraftLink::OverlayPending() const {
    if (!m_Base)
        return false;
    auto& state = At<hitcraft::proto::OverlayCtl>(hitcraft::proto::kOffOverlayCtl)->state;
    return (Atomic(state).load(std::memory_order_acquire) & hitcraft::proto::kOverlayDirty) != 0;
}

bool HitCraftLink::AcquireOverlay(const std::uint8_t*& p_Pixels, std::uint32_t& p_Width, std::uint32_t& p_Height,
    bool& p_BottomUp) {
    if (!OverlayPending())
        return false;
    auto& state = At<hitcraft::proto::OverlayCtl>(hitcraft::proto::kOffOverlayCtl)->state;
    const auto previous = Atomic(state).exchange(m_OverlayFront, std::memory_order_acq_rel);
    m_OverlayFront = previous & 3;
    if (m_OverlayFront >= hitcraft::proto::kOverlaySlots)
        return false;
    const auto* header = At<hitcraft::proto::OverlaySlotHdr>(
        hitcraft::proto::kOffOverlaySlotHdr + m_OverlayFront * sizeof(hitcraft::proto::OverlaySlotHdr));
    if (header->width == 0 || header->height == 0 || header->width > hitcraft::proto::kMaxOverlayW ||
        header->height > hitcraft::proto::kMaxOverlayH)
        return false;
    p_Width = header->width;
    p_Height = header->height;
    p_BottomUp = (header->flags & 1) != 0;
    p_Pixels = m_Base + hitcraft::proto::kOffOverlayPixels + m_OverlayFront * hitcraft::proto::kOverlaySlotBytes;
    return true;
}

bool HitCraftLink::ReadSelection(float p_Min[3], float p_Max[3]) const {
    if (!m_Base)
        return false;
    auto* source = At<hitcraft::proto::WorldEntitiesHeader>(hitcraft::proto::kOffWorldEntities);
    auto seq = Atomic(source->seq);
    for (int attempt = 0; attempt < 16; ++attempt) {
        const auto first = seq.load(std::memory_order_acquire);
        if (first & 1) {
            _mm_pause();
            continue;
        }
        hitcraft::proto::WorldEntitiesHeader copy;
        std::memcpy(&copy, source, sizeof(copy));
        std::atomic_thread_fence(std::memory_order_acquire);
        if (seq.load(std::memory_order_relaxed) != first)
            continue;
        if (!copy.hasSelection)
            return false;
        std::memcpy(p_Min, copy.selMin, sizeof(copy.selMin));
        std::memcpy(p_Max, copy.selMax, sizeof(copy.selMax));
        return true;
    }
    return false;
}

bool HitCraftLink::ReadWorldEntities(std::vector<hitcraft::proto::WorldEntity>& p_Out) const {
    p_Out.clear();
    if (!m_Base)
        return false;
    auto* header = At<hitcraft::proto::WorldEntitiesHeader>(hitcraft::proto::kOffWorldEntities);
    const auto* records = At<hitcraft::proto::WorldEntity>(hitcraft::proto::kOffWorldEntities + sizeof(*header));
    auto seq = Atomic(header->seq);
    for (int attempt = 0; attempt < 8; ++attempt) {
        const auto first = seq.load(std::memory_order_acquire);
        if (first & 1) {
            _mm_pause();
            continue;
        }
        const std::uint32_t count = header->count;
        if (count > hitcraft::proto::kMaxWorldEntities)
            continue;
        p_Out.assign(records, records + count);
        std::atomic_thread_fence(std::memory_order_acquire);
        if (seq.load(std::memory_order_relaxed) == first)
            return true;
    }
    p_Out.clear();
    return false;
}

void HitCraftLink::WriteActors(const hitcraft::proto::ActorRecord* p_Actors, std::uint32_t p_Count) {
    if (!m_Base)
        return;
    if (p_Count > hitcraft::proto::kMaxActors)
        p_Count = hitcraft::proto::kMaxActors;
    auto* header = At<hitcraft::proto::ActorTableHeader>(hitcraft::proto::kOffActorTable);
    auto* records = At<hitcraft::proto::ActorRecord>(hitcraft::proto::kOffActorTable + sizeof(*header));
    auto seq = Atomic(header->seq);
    const auto current = seq.load(std::memory_order_relaxed);
    seq.store(current + 1, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_release);
    header->count = p_Count;
    if (p_Count)
        std::memcpy(records, p_Actors, p_Count * sizeof(hitcraft::proto::ActorRecord));
    seq.store(current + 2, std::memory_order_release);
}

void HitCraftLink::DrainEvents(const std::function<void(const hitcraft::proto::McEvent&)>& p_Consumer) {
    if (!m_Base)
        return;
    auto* ring = m_Base + hitcraft::proto::kOffEventRing;
    auto& headValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kEventRingHeadOff);
    auto& tailValue = *reinterpret_cast<std::uint64_t*>(ring + hitcraft::proto::kEventRingTailOff);
    const auto head = Atomic(headValue).load(std::memory_order_acquire);
    auto tail = Atomic(tailValue).load(std::memory_order_relaxed);
    if (head - tail > hitcraft::proto::kEventRingEntries)
        tail = head - hitcraft::proto::kEventRingEntries;
    const auto* events = reinterpret_cast<const hitcraft::proto::McEvent*>(ring + hitcraft::proto::kEventRingDataOff);
    while (tail < head) {
        const hitcraft::proto::McEvent event = events[tail & (hitcraft::proto::kEventRingEntries - 1)];
        ++tail;
        p_Consumer(event);
    }
    Atomic(tailValue).store(tail, std::memory_order_release);
}
