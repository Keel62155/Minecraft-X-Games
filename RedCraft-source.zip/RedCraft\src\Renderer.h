#pragma once

#include "Game.h"
#include "Link.h"

#include <Windows.h>
#include <cstdint>
#include <vector>

/**
 * Draws Minecraft into the game's picture: its block meshes in the world, then its own frame
 * (hand, hotbar, hearts, screens) on top. There is no overlay framework to lean on here, so this
 * is a small D3D12 pass of its own, run on the game's swap chain right before each present.
 */
namespace Renderer {
/** Hooks DirectX 12's present and command queue. Call until it returns true. */
bool Install();
/** The shared-memory link the render thread reads Minecraft's frames and meshes from. */
void SetLink(HitCraftLink* p_Link);
/** This frame's camera (from the main thread). p_Valid false hides the blocks. */
void SetCamera(const Game::Camera& p_Camera, bool p_Valid);
/** Whether anything is drawn at all, and whether the crosshair-level HUD is. */
/** Where the Minecraft player's body is drawn: V's feet (game coordinates) and Minecraft's yaw. */
void SetPlayer(const Game::Vec3& p_Feet, float p_MinecraftYaw, bool p_Visible, bool p_ThirdPerson);
void SetEnabled(bool p_Enabled);
/** Minecraft's screen cursor, in overlay pixels (its own window is hidden and has none). */
void SetCursor(bool p_Visible, float p_X, float p_Y);

/** A Minecraft block that burns what stands in it (kind 1 fire, 2 lava) or on it (3 magma). */
struct Hazard {
    std::int32_t x, y, z; // Minecraft block coordinates
    std::uint8_t kind;
};
/** Every such block Minecraft has told us about. Any thread. */
void CopyHazards(std::vector<Hazard>& p_Out);

/** How many frames the game has presented through DirectX 12 (zero means it runs on Vulkan). */
std::uint64_t Presents();
std::uint32_t Width();
std::uint32_t Height();
HWND Window();
std::uint64_t OverlayFrames();
std::size_t Sections();
}
