#pragma once

#include "Link.h"

#include <cstdint>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <vector>

/**
 * The game world as Minecraft collision.
 *
 * The engine only exposes ray casts, so the walkable surface around the player is discovered by
 * flood fill: from the player's feet, step to each neighbouring grid point if nothing blocks the
 * way at knee, waist and chest height, and drop a ray there to find the floor. Open steps become
 * floor triangles, blocked steps become wall triangles, and the result is streamed to Minecraft in
 * the SkyCraft collision format (exact triangles for the player, 1/8-block voxels for everything
 * else). Game thread only.
 */
class HitCraftCollision {
public:
    struct Vec3 {
        float x = 0.f, y = 0.f, z = 0.f;
    };

    struct Stats {
        std::uint32_t nodes = 0;
        std::uint32_t raysLastFrame = 0;
        std::uint32_t cycles = 0;
        std::uint32_t regionsSent = 0;
        std::uint32_t triangles = 0;
        std::uint64_t rays = 0;
        std::uint64_t hits = 0;
        float cycleMs = 0.f;
        bool staticOnly = true;
        bool hasGround = false;
    };

    /** Closest hit of the game's static collision along a segment (game coordinates), or false. */
    using Raycaster = std::function<bool(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit)>;
    void SetRaycaster(Raycaster p_Raycaster) { m_Raycaster = std::move(p_Raycaster); }
    /** A second caster asked for a floor only where the first finds none (lifts, vehicles, props). */
    void SetFloorFallback(Raycaster p_Raycaster) { m_FloorFallback = std::move(p_Raycaster); }

    /**
     * Adds a small patch of surface at a point a ray hit (game coordinates, outward normal). The flood
     * fill only knows what can be walked to; these cover everything else that can be seen: walls above
     * head height, facades across the street, roofs. Arrows, the crosshair and the player collide with them.
     */
    void AddSurfel(const Vec3& p_Position, const Vec3& p_Normal);

    /** The world changed: forget everything. */
    void Reset();
    /** Minecraft (re)connected or its collision was cleared: send every region again. */
    void ForgetSent();
    /** Call once per game frame with the player's feet in Hitman coordinates. */
    void Update(HitCraftLink& p_Link, std::uint32_t p_Epoch, const Vec3& p_Player, bool p_CanSend);
    /** Closest hit of Hitman's collision geometry along a segment (Hitman coordinates). */
    bool Cast(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit);

    const Stats& GetStats() const { return m_Stats; }

private:
    enum Edge : std::uint8_t { kUnknown = 0, kOpen = 1, kBlocked = 2 };

    struct Node {
        int ix = 0, iy = 0;
        float z = 0.f;
        int next[4] = { -1, -1, -1, -1 };
        std::uint8_t edge[4] = {};
        float wall[4] = {};
        double scannedAt = 0.0;
        std::uint32_t stamp = 0;
        std::uint8_t cells = 0;
    };

    int FindNode(int p_Ix, int p_Iy, float p_Z, float p_Tolerance) const;
    int AddNode(int p_Ix, int p_Iy, float p_Z);
    void Visit(int p_Node);
    bool BeginCycle(const Vec3& p_Player);
    void ScanNode(int p_Node, double p_Now);
    int OpenNeighbor(int p_Node, int p_Direction) const;
    void BuildAndSend(HitCraftLink& p_Link, std::uint32_t p_Epoch, bool p_CanSend, bool p_OnlyUnknown);
    bool SendRegion(HitCraftLink& p_Link, std::uint32_t p_Epoch, int p_Rx, int p_Ry, int p_Rz,
        const std::vector<hitcraft::proto::ColTri>& p_Triangles);

    std::vector<Node> m_Nodes;
    std::unordered_map<std::uint64_t, std::vector<int>> m_Grid;
    std::vector<int> m_Queue;
    std::size_t m_QueueHead = 0;
    bool m_CycleActive = false;
    std::uint32_t m_Stamp = 0;
    Vec3 m_Center;
    double m_CycleStart = 0.0;
    double m_LastCycleEnd = 0.0;
    std::uint32_t m_SeedFailures = 0;
    std::uint32_t m_RaysThisFrame = 0;
    std::unordered_map<std::uint64_t, std::uint64_t> m_Sent;
    Stats m_Stats;
    Raycaster m_Raycaster;
    Raycaster m_FloorFallback;

    struct StaticRegion {
        int rx = 0, ry = 0, rz = 0;
        std::vector<hitcraft::proto::ColTri> triangles;
        std::uint64_t hash = 0;
    };
    std::unordered_map<std::uint64_t, StaticRegion> m_Static;
    std::unordered_set<std::uint64_t> m_StaticDirty;
    std::unordered_set<std::uint64_t> m_SurfelKeys;
    bool CastFloor(const Vec3& p_From, const Vec3& p_To, Vec3& p_Hit);
};
