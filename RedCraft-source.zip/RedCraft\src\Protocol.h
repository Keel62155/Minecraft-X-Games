#pragma once

// The subset of SkyCraft's MIT-licensed v11 shared-memory protocol used by
// HitCraft. The Minecraft Fabric side can therefore run unchanged.
// Source of truth: vendor/SkyCraft/protocol/skycraft_protocol.h

#include <cstdint>

namespace hitcraft::proto {
inline constexpr std::uint32_t kMagic = 0x43594B53; // "SKYC"
inline constexpr std::uint32_t kVersion = 11;
inline constexpr wchar_t kMappingName[] = L"Local\\SkyCraft_v1";
inline constexpr wchar_t kMinecraftMutexName[] = L"Local\\SkyCraft_v1_minecraft";

inline constexpr std::uint64_t kOffHeader = 0x0;
inline constexpr std::uint64_t kOffSkyState = 0x100;
inline constexpr std::uint64_t kOffMcState = 0x200;
inline constexpr std::uint64_t kOffOverlayCtl = 0x300;
inline constexpr std::uint64_t kOffOverlaySlotHdr = 0x340; // 3 x 0x40
inline constexpr std::uint64_t kOffWaterGrid = 0x400;
inline constexpr std::uint64_t kWaterGridBytes = 0xC00;
inline constexpr std::uint64_t kOffInputRing = 0x1000;
inline constexpr std::uint64_t kOffActorTable = 0x12000;
inline constexpr std::uint64_t kOffEventRing = 0x17000;
inline constexpr std::uint64_t kOffWorldEntities = 0x1C000;
inline constexpr std::uint64_t kOffCollisionRing = 0x20000;
inline constexpr std::uint64_t kCollisionRingBytes = 32ull << 20;
inline constexpr std::uint32_t kMaxOverlayW = 3840;
inline constexpr std::uint32_t kMaxOverlayH = 2160;
inline constexpr std::uint64_t kOverlaySlotBytes = std::uint64_t(kMaxOverlayW) * kMaxOverlayH * 4;
inline constexpr std::uint32_t kOverlaySlots = 3;
inline constexpr std::uint64_t kOffOverlayPixels = kOffCollisionRing + kCollisionRingBytes;
inline constexpr std::uint64_t kOffRenderRing = kOffOverlayPixels + kOverlaySlotBytes * kOverlaySlots;
inline constexpr std::uint64_t kRenderRingBytes = 64ull << 20;
inline constexpr std::uint64_t kMappingBytes = kOffRenderRing + kRenderRingBytes;

struct Header {
    std::uint32_t magic, version, skyrimPid, mcPid;
    std::uint64_t skyrimHeartbeatMs, mcHeartbeatMs;
};
static_assert(sizeof(Header) == 0x20);

enum SkyFlags : std::uint32_t {
    kSkyInGame = 1u << 0,
    kSkyMenuOpen = 1u << 1,
    kSkyLoading = 1u << 2,
};

struct SkyState {
    std::uint32_t seq, flags, worldId, collisionEpoch;
    double posX, posY, posZ;
    float yaw, pitch;
    std::uint32_t teleportSeq, viewportW, viewportH;
    float gameHour;
};
static_assert(sizeof(SkyState) == 0x40);

enum McFlags : std::uint32_t {
    kMcInWorld = 1u << 0,
    kMcScreenOpen = 1u << 1,
    kMcOnGround = 1u << 2,
    kMcSneaking = 1u << 3,
    kMcSprinting = 1u << 4,
    kMcDead = 1u << 5,
    kMcSwimming = 1u << 6,
    kMcFlying = 1u << 7,
};

inline constexpr std::uint32_t kInputRingEntries = 4096;
inline constexpr std::uint64_t kInputRingHeadOff = 0x00;
inline constexpr std::uint64_t kInputRingTailOff = 0x40;
inline constexpr std::uint64_t kInputRingDataOff = 0x80;
enum InputType : std::uint16_t {
    kInKey = 1,          // code = SDL scancode, a = 1 press / 0 release
    kInMouseButton = 2,  // code = SDL button (1 L, 2 M, 3 R, 4 X1, 5 X2)
    kInScroll = 3,       // a = wheel notches * 120
    kInCursor = 4,       // a, b = absolute cursor position in overlay pixels
    kInText = 5,         // a = unicode code point
    kInReleaseAll = 6,
    kInOpenMenu = 8,
};
struct InputEvent {
    std::uint16_t type, code;
    std::int32_t a, b, c;
};
static_assert(sizeof(InputEvent) == 16);

struct McState {
    std::uint32_t seq, flags;
    double x, y, z;
    float yaw, pitch, eyeHeight, sensitivity;
    std::uint32_t teleportAck, guiScale;
    std::uint64_t frameCounter;
    float fovDeg, bobPhase, bobAmount;
    std::uint32_t pad4C;
    double eyeX, eyeY, eyeZ;
    std::int64_t tickQpc;
    double prevX, prevY, prevZ, curX, curY, curZ;
    float tickEyeO, tickEye, walkDistO, walkDist, bobO, bob, tickMs;
    std::uint32_t tickPad, cameraMode;
    float cameraDistance;
};
static_assert(sizeof(McState) == 0xC8);

// Overlay triple buffer. state: bits 0-1 = index of the "middle" slot, bit 2 = middle holds an
// unread frame. The reader (us) swaps its front slot in only when the dirty bit is set.
inline constexpr std::uint32_t kOverlayDirty = 1u << 2;
struct OverlayCtl {
    std::uint32_t state, pad;
    std::uint64_t framesPublished;
};
struct OverlaySlotHdr {
    std::uint32_t width, height, flags, pad; // flags bit0: rows are bottom-up
    std::uint64_t frameId;
    std::uint8_t reserved[0x40 - 0x18];
};
static_assert(sizeof(OverlaySlotHdr) == 0x40);

// Actor table (host -> MC, seqlock): nearby NPCs, mirrored in Minecraft as invisible hittable
// stand-ins.
inline constexpr std::uint32_t kMaxActors = 256;
enum ActorFlags : std::uint32_t {
    kActorHostile = 1u << 0,
    kActorDead = 1u << 1,
    kActorEssential = 1u << 2,
    kActorInCombat = 1u << 3,
};
struct ActorRecord {
    std::uint32_t formId, flags;
    float x, y, z;      // feet, MC coords
    float yaw;          // MC degrees
    float width, height;
    float healthFrac;
    std::uint16_t level, pad;
    char name[24];
};
static_assert(sizeof(ActorRecord) == 64);
struct ActorTableHeader {
    std::uint32_t seq, count;
    std::uint8_t pad[0x40 - 8];
};
static_assert(sizeof(ActorTableHeader) == 0x40);

// Event ring (MC -> host).
inline constexpr std::uint32_t kEventRingEntries = 512;
inline constexpr std::uint64_t kEventRingHeadOff = 0x00;
inline constexpr std::uint64_t kEventRingTailOff = 0x40;
inline constexpr std::uint64_t kEventRingDataOff = 0x80;
enum McEventType : std::uint32_t {
    kEvHitActor = 1,    // formId, a = MC damage, b/c = knockback direction x/z (MC), d = knockback strength
    kEvPlayerDied = 2,
    kEvExplosion = 3,   // a/b/c = centre (MC coords), d = radius (blocks)
    kEvArrowStuck = 4,
    kEvSkillUse = 5,
};
struct McEvent {
    std::uint32_t type, formId;
    float a, b, c, d;
    std::uint32_t flags, weapon;
};
static_assert(sizeof(McEvent) == 32);

// World entities (MC -> host, seqlock): things the host draws itself each frame, plus the outline
// of the targeted block.
inline constexpr std::uint32_t kMaxWorldEntities = 160;
enum WorldEntityKind : std::uint32_t {
    kWeArrow = 1,    // uv[0]: the arrow's item icon
    kWeItem = 2,     // dropped item: a flat sprite (uv[0]) turning about the vertical
    kWeTrident = 3,
    kWeBlock = 4,    // dropped block: a cube of side `scale`, uv[0..2] = side, top, bottom
    kWeCrack = 5,
    kWeShadow = 6,
};
struct WorldEntity {
    std::uint32_t kind, id;
    float x, y, z;
    float yaw, pitch;
    float scale;
    float ext[3];
    float uv[3][4];  // atlas rects {u0, v0, u1, v1}
    std::uint32_t tint;
};
static_assert(sizeof(WorldEntity) == 96);
struct WorldEntitiesHeader {
    std::uint32_t seq, count, hasSelection;
    float selMin[3], selMax[3];
    std::uint8_t pad[0x40 - 36];
};
static_assert(sizeof(WorldEntitiesHeader) == 0x40);

inline constexpr std::uint64_t kColRingHeadOff = 0x00;
inline constexpr std::uint64_t kColRingTailOff = 0x40;
inline constexpr std::uint64_t kColRingDataOff = 0x80;
inline constexpr std::uint64_t kColRingDataBytes = kCollisionRingBytes - kColRingDataOff;

// Collision is streamed per cube of this many blocks (must match SkyCollision.REGION_SIZE).
inline constexpr int kRegionSize = 8;

enum ColType : std::uint32_t { kColPad = 0, kColClear = 1, kColRegion = 2, kColTris = 3 };
struct ColMsgHeader { std::uint32_t type, payloadBytes; };
struct ColRegion {
    std::int32_t minX, minY, minZ, maxX, maxY, maxZ;
    std::uint32_t epoch, count;
};
struct ColTri { float v[9]; std::uint32_t flags; };
// One block's worth of collision as an 8x8x8 occupancy mask: bits[y] bit (z * 8 + x).
struct ColBlock {
    std::int32_t x, y, z;
    std::uint32_t pad;
    std::uint64_t bits[8];
};
static_assert(sizeof(ColRegion) == 32);
static_assert(sizeof(ColTri) == 40);
static_assert(sizeof(ColBlock) == 80);

inline constexpr std::uint64_t kRenRingHeadOff = 0x00;
inline constexpr std::uint64_t kRenRingTailOff = 0x40;
inline constexpr std::uint64_t kRenRingDataOff = 0x80;
inline constexpr std::uint64_t kRenRingDataBytes = kRenderRingBytes - kRenRingDataOff;

enum RenType : std::uint32_t {
    kRenPad = 0,
    kRenAtlas = 1,    // RenAtlas + RGBA8 pixels (w * h * 4), top row first
    kRenSection = 2,  // RenSection + RenVertex[vertexCount] (triangle list); 0 vertices = remove
    kRenClearAll = 3,
    kRenTexture = 4,  // RenTexture + RGBA8 pixels: an entity texture (player skin, armour, ...)
    kRenAvatar = 5,   // RenAvatar + RenBatch[] + RenVertex[]: the player's model this frame, relative to the feet
    kRenScene = 6,    // RenScene + RenBatch[] + RenVertex[]: every other entity and all particles this frame
};

struct RenTexture {
    std::uint32_t id, width, height, pad;
};

struct RenAvatar {
    std::uint32_t batchCount, vertexCount;
};

struct RenScene {
    double originX, originY, originZ;
    std::uint32_t batchCount, vertexCount;
};
static_assert(sizeof(RenScene) == 32);

struct RenBatch {
    std::uint32_t texture; // 0: the block/item atlas, else a RenTexture id
    std::uint32_t first, count;
    std::uint32_t flags;   // bit0: translucent
};

struct RenAtlas {
    std::uint32_t width, height;
};

struct RenSection {
    std::int32_t sx, sy, sz;
    std::uint32_t vertexCount;
};

struct RenVertex {
    float x, y, z;       // MC coords relative to the section origin
    float u, v;          // atlas UV
    std::uint32_t color; // RGBA8 (tint * ambient occlusion)
    std::uint32_t light; // low byte: block light 0-15, next byte: sky light 0-15
    std::uint32_t flags; // bit0 cutout, bit1 translucent, bits 4-6: MC Direction ordinal + 1
};
static_assert(sizeof(RenVertex) == 32);
}
