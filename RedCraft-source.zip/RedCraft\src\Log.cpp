#include "Log.h"

#include <Windows.h>
#include <cstdarg>
#include <cstdio>
#include <mutex>
#include <string>

namespace {
std::mutex g_LogMutex;
FILE* g_LogFile = nullptr;
bool g_LogOpened = false;

void OpenLog() {
    g_LogOpened = true;
    wchar_t localAppData[MAX_PATH]{};
    const auto length = ::GetEnvironmentVariableW(L"LOCALAPPDATA", localAppData, MAX_PATH);
    if (!length || length >= MAX_PATH)
        return;
    const std::wstring directory = std::wstring(localAppData) + L"\\RedCraft";
    ::CreateDirectoryW(directory.c_str(), nullptr);
    g_LogFile = _wfsopen((directory + L"\\redcraft.log").c_str(), L"w", _SH_DENYNO);
}
}

void HcLog(const char* p_Format, ...) {
    std::scoped_lock lock(g_LogMutex);
    if (!g_LogOpened)
        OpenLog();
    if (!g_LogFile)
        return;
    SYSTEMTIME now;
    ::GetLocalTime(&now);
    std::fprintf(g_LogFile, "[%02u:%02u:%02u.%03u] ", now.wHour, now.wMinute, now.wSecond, now.wMilliseconds);
    va_list arguments;
    va_start(arguments, p_Format);
    std::vfprintf(g_LogFile, p_Format, arguments);
    va_end(arguments);
    std::fputc('\n', g_LogFile);
    std::fflush(g_LogFile);
}
