#pragma once

// A plain text log at %LOCALAPPDATA%\HitCraft\hitcraft.log, so a session can be diagnosed
// afterwards without the mod SDK's console.

void HcLog(const char* p_Format, ...);
