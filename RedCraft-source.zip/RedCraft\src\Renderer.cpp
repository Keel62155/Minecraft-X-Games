#include "Renderer.h"

#include "Log.h"

#include <Windows.h>
#include <d3d12.h>
#include <d3dcompiler.h>
#include <dxgi1_4.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <initializer_list>
#include <map>
#include <mutex>
#include <tuple>
#include <vector>

namespace {
using namespace hitcraft::proto;

const char kShaders[] = R"(
cbuffer Constants : register(b0) {
    float4 row0, row1, row2, row3; // camera-relative world -> clip
    float4 offset;                 // section origin minus the camera
    float4 misc;                   // x: alpha cut-off, y: flip the overlay vertically
};
Texture2D image : register(t0);
SamplerState pointWrap : register(s0);
SamplerState linearClamp : register(s1);

struct BlockIn { float3 position : POSITION; float4 color : COLOR; float2 uv : TEXCOORD; };
struct Varying { float4 position : SV_Position; float4 color : COLOR; float2 uv : TEXCOORD; };

Varying BlockVS(BlockIn input) {
    float3 p = input.position + offset.xyz;
    Varying output;
    output.position = float4(dot(row0.xyz, p), dot(row1.xyz, p), dot(row2.xyz, p) + row2.w, dot(row3.xyz, p));
    output.color = input.color;
    output.uv = input.uv;
    return output;
}

float4 BlockPS(Varying input) : SV_Target {
    float4 color = image.Sample(pointWrap, input.uv) * input.color;
    clip(color.a - misc.x);
    return color;
}

Varying OverlayVS(uint id : SV_VertexID) {
    float2 uv = float2((id << 1) & 2, id & 2);
    Varying output;
    output.position = float4(uv * float2(2, -2) + float2(-1, 1), 0, 1);
    output.color = float4(1, 1, 1, 1);
    output.uv = float2(uv.x, misc.y > 0.5 ? 1 - uv.y : uv.y);
    return output;
}

float4 OverlayPS(Varying input) : SV_Target {
    return image.Sample(linearClamp, input.uv); // premultiplied alpha, straight from Minecraft
}
)";

struct Vertex {
    float x, y, z;
    std::uint32_t color;
    float u, v;
};

using SectionKey = std::tuple<std::int32_t, std::int32_t, std::int32_t>;

struct Section {
    ID3D12Resource* buffer = nullptr;
    std::uint32_t opaque = 0;
    std::uint32_t translucent = 0;
    double origin[3] = {}; // game coordinates
};

struct Slot {
    ID3D12CommandAllocator* allocator = nullptr;
    std::uint64_t fenceValue = 0;
    ID3D12Resource* upload = nullptr; // this slot's copy of the overlay frame
    std::uint8_t* mapped = nullptr;
    std::uint64_t capacity = 0;
    ID3D12Resource* regions = nullptr; // this frame's animated-texture updates
    std::uint8_t* regionsMapped = nullptr;
    std::uint64_t regionsCapacity = 0;
    ID3D12Resource* dynamic = nullptr; // this frame's entity geometry
    std::uint8_t* dynamicMapped = nullptr;
    std::uint64_t dynamicCapacity = 0;
};

struct Constants {
    float row0[4], row1[4], row2[4], row3[4], offset[4], misc[4];
};

// Shared with the main thread
std::atomic<HitCraftLink*> g_Link = nullptr;
std::atomic_bool g_Enabled = false;
std::atomic<std::uint32_t> g_Width = 0, g_Height = 0;
std::atomic<HWND> g_Window = nullptr;
std::atomic<std::uint64_t> g_OverlayFrames = 0;
std::atomic<std::size_t> g_SectionCount = 0;
std::mutex g_CameraMutex;
Game::Camera g_Camera;
bool g_CameraValid = false;
Game::Vec3 g_PlayerFeet;      // game coordinates
float g_PlayerYaw = 0.f;      // Minecraft degrees
bool g_PlayerVisible = false;
bool g_PlayerThirdPerson = false;

// Hook
using Present_t = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using Present1_t = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain1*, UINT, UINT, const DXGI_PRESENT_PARAMETERS*);
Present_t g_OriginalPresent = nullptr;
Present1_t g_OriginalPresent1 = nullptr;
bool g_Installed = false;
// The game's own command queue, caught as it submits work (RDR2 gives plugins no access to it).
using ExecuteCommandLists_t = void(STDMETHODCALLTYPE*)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);
ExecuteCommandLists_t g_OriginalExecute = nullptr;
std::atomic<ID3D12CommandQueue*> g_CapturedQueue = nullptr;
std::atomic<std::uint64_t> g_Presents = 0;

// Render thread
bool g_Failed = false;
ID3D12Device* g_Device = nullptr;
ID3D12CommandQueue* g_Queue = nullptr;
ID3D12GraphicsCommandList* g_List = nullptr;
ID3D12Fence* g_Fence = nullptr;
std::uint64_t g_FenceValue = 0;
Slot g_Slots[4];
ID3D12RootSignature* g_RootSignature = nullptr;
ID3D12PipelineState* g_BlockPipeline = nullptr;
ID3D12PipelineState* g_BlendPipeline = nullptr;
ID3D12PipelineState* g_OverlayPipeline = nullptr;
DXGI_FORMAT g_PipelineFormat = DXGI_FORMAT_UNKNOWN;
ID3DBlob* g_BlockVS = nullptr;
ID3DBlob* g_BlockPS = nullptr;
ID3DBlob* g_OverlayVS = nullptr;
ID3DBlob* g_OverlayPS = nullptr;
ID3D12DescriptorHeap* g_RtvHeap = nullptr;
ID3D12DescriptorHeap* g_DsvHeap = nullptr;
ID3D12DescriptorHeap* g_SrvHeap = nullptr; // 0: block atlas, 1: overlay, 2: cursor, 3+: entity textures
constexpr UINT kFirstEntitySrv = 3;
constexpr UINT kSrvCount = 256;
UINT g_SrvSize = 0;
ID3D12Resource* g_Depth = nullptr;
std::uint32_t g_DepthW = 0, g_DepthH = 0;

ID3D12Resource* g_AtlasTexture = nullptr;
ID3D12Resource* g_AtlasUpload = nullptr;
std::vector<std::uint8_t> g_Atlas;
std::uint32_t g_AtlasW = 0, g_AtlasH = 0;
bool g_AtlasDirty = false;

ID3D12Resource* g_OverlayTexture = nullptr;
std::uint32_t g_OverlayW = 0, g_OverlayH = 0;
bool g_OverlayBottomUp = false;
bool g_HaveOverlay = false;

constexpr std::uint32_t kCursorSize = 16;
ID3D12Resource* g_CursorTexture = nullptr;
ID3D12Resource* g_CursorUpload = nullptr;
std::atomic_bool g_CursorVisible = false;
std::atomic<float> g_CursorX = 0.f, g_CursorY = 0.f; // overlay pixels

std::map<SectionKey, Section> g_Sections;

// Entities and particles: Minecraft sends the whole lot as one mesh every frame, plus the
// textures it uses (mob skins, the TNT model...).
struct EntityTexture {
    ID3D12Resource* texture = nullptr;
    UINT srv = 0;
};
struct PendingTexture {
    std::uint32_t id, width, height;
    std::vector<std::uint8_t> pixels;
};
struct SceneBatch {
    std::uint32_t texture, first, count;
    bool translucent;
};
std::map<std::uint32_t, EntityTexture> g_EntityTextures;
std::vector<PendingTexture> g_PendingTextures;
UINT g_NextEntitySrv = kFirstEntitySrv;
std::vector<Vertex> g_SceneVertices;
std::vector<SceneBatch> g_SceneBatches;
double g_SceneOrigin[3] = {}; // game coordinates
std::uint64_t g_SceneMessages = 0;
// The Minecraft player's own body (skin, armour), standing, relative to the feet and facing +Z.
// Minecraft sends it about once a second; it is drawn where V stands so the player sees their
// Minecraft self when looking down.
constexpr std::uint32_t kRenRagdoll = 9;
constexpr std::uint32_t kPartBody = 2, kPartRightLeg = 5, kPartLeftLeg = 6;
struct BodyBatch {
    std::uint32_t texture, first, count, part;
    bool translucent;
};
std::vector<Vertex> g_BodyVertices; // Minecraft axes
std::vector<BodyBatch> g_BodyBatches;
// In Minecraft's third-person views (F5) it sends the posed, animated player every frame instead.
constexpr std::uint32_t kRenAvatarMessage = 5;
std::vector<Vertex> g_AvatarVertices; // Minecraft axes, already turned to the player's heading
std::vector<BodyBatch> g_AvatarBatches;
std::vector<WorldEntity> g_WorldEntities;
std::vector<Vertex> g_EntityVertices;

// Animated block textures (fire, water, lava...): Minecraft sends the current frame of each as a
// rectangle of the atlas.
constexpr std::uint32_t kRenAtlasRegion = 7;
struct AtlasRegion {
    std::uint32_t x, y, width, height;
    std::vector<std::uint8_t> pixels;
};
std::vector<AtlasRegion> g_PendingRegions;

// Light-emitting blocks per section; the ones flagged as hazards are what burns people.
constexpr std::uint32_t kRenLights = 8;
std::mutex g_HazardMutex;
std::map<SectionKey, std::vector<Renderer::Hazard>> g_Hazards;
std::vector<std::pair<ID3D12Resource*, std::uint64_t>> g_Garbage;
std::uint64_t g_Frame = 0;

template <typename T>
void Release(T*& p_Object) {
    if (p_Object) {
        p_Object->Release();
        p_Object = nullptr;
    }
}

void Discard(ID3D12Resource*& p_Resource) {
    // Still referenced by frames the GPU has not finished: let a few go by first.
    if (p_Resource)
        g_Garbage.emplace_back(p_Resource, g_Frame);
    p_Resource = nullptr;
}

bool Fail(const char* p_What, HRESULT p_Result) {
    g_Failed = true;
    HcLog("renderer: %s failed (0x%08X); drawing is off for this session", p_What, static_cast<unsigned>(p_Result));
    return false;
}

ID3D12Resource* CreateBuffer(std::uint64_t p_Bytes, std::uint8_t** p_Mapped) {
    D3D12_HEAP_PROPERTIES heap {};
    heap.Type = D3D12_HEAP_TYPE_UPLOAD;
    D3D12_RESOURCE_DESC description {};
    description.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    description.Width = p_Bytes;
    description.Height = 1;
    description.DepthOrArraySize = 1;
    description.MipLevels = 1;
    description.SampleDesc.Count = 1;
    description.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    ID3D12Resource* buffer = nullptr;
    if (FAILED(g_Device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &description, D3D12_RESOURCE_STATE_GENERIC_READ,
            nullptr, IID_PPV_ARGS(&buffer))))
        return nullptr;
    void* mapped = nullptr;
    if (FAILED(buffer->Map(0, nullptr, &mapped))) {
        buffer->Release();
        return nullptr;
    }
    *p_Mapped = static_cast<std::uint8_t*>(mapped);
    return buffer;
}

ID3D12Resource* CreateTexture(std::uint32_t p_Width, std::uint32_t p_Height, UINT p_SrvIndex) {
    D3D12_HEAP_PROPERTIES heap {};
    heap.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC description {};
    description.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    description.Width = p_Width;
    description.Height = p_Height;
    description.DepthOrArraySize = 1;
    description.MipLevels = 1;
    description.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    description.SampleDesc.Count = 1;
    ID3D12Resource* texture = nullptr;
    if (FAILED(g_Device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &description,
            D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, nullptr, IID_PPV_ARGS(&texture))))
        return nullptr;
    auto handle = g_SrvHeap->GetCPUDescriptorHandleForHeapStart();
    handle.ptr += static_cast<SIZE_T>(p_SrvIndex) * g_SrvSize;
    g_Device->CreateShaderResourceView(texture, nullptr, handle);
    return texture;
}

void Transition(ID3D12Resource* p_Resource, D3D12_RESOURCE_STATES p_Before, D3D12_RESOURCE_STATES p_After) {
    D3D12_RESOURCE_BARRIER barrier {};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = p_Resource;
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = p_Before;
    barrier.Transition.StateAfter = p_After;
    g_List->ResourceBarrier(1, &barrier);
}

void CopyToTexture(ID3D12Resource* p_Texture, ID3D12Resource* p_Upload, std::uint32_t p_Width, std::uint32_t p_Height,
    std::uint32_t p_RowPitch) {
    Transition(p_Texture, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
    D3D12_TEXTURE_COPY_LOCATION destination {};
    destination.pResource = p_Texture;
    destination.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    D3D12_TEXTURE_COPY_LOCATION source {};
    source.pResource = p_Upload;
    source.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
    source.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    source.PlacedFootprint.Footprint.Width = p_Width;
    source.PlacedFootprint.Footprint.Height = p_Height;
    source.PlacedFootprint.Footprint.Depth = 1;
    source.PlacedFootprint.Footprint.RowPitch = p_RowPitch;
    g_List->CopyTextureRegion(&destination, 0, 0, 0, &source, nullptr);
    Transition(p_Texture, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
}

ID3DBlob* Compile(const char* p_Entry, const char* p_Target) {
    ID3DBlob* code = nullptr;
    ID3DBlob* errors = nullptr;
    const HRESULT result = ::D3DCompile(kShaders, sizeof(kShaders) - 1, "CyberCraft", nullptr, nullptr, p_Entry, p_Target,
        D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &code, &errors);
    if (FAILED(result)) {
        HcLog("renderer: shader %s: %s", p_Entry, errors ? static_cast<const char*>(errors->GetBufferPointer()) : "?");
        Fail("compiling a shader", result);
    }
    if (errors)
        errors->Release();
    return code;
}

bool CreateDeviceObjects(IDXGISwapChain* p_SwapChain) {
    if (FAILED(p_SwapChain->GetDevice(IID_PPV_ARGS(&g_Device))))
        return Fail("getting the device", E_FAIL);
    // The queue must be one of this device's: if the one caught first is not, wait for another.
    ID3D12CommandQueue* queue = g_CapturedQueue.load(std::memory_order_acquire);
    ID3D12Device* owner = nullptr;
    if (!queue || FAILED(queue->GetDevice(IID_PPV_ARGS(&owner))) || owner != g_Device) {
        if (owner)
            owner->Release();
        if (queue && owner != g_Device)
            g_CapturedQueue.store(nullptr, std::memory_order_release);
        g_Device->Release();
        g_Device = nullptr;
        return false;
    }
    owner->Release();
    g_Queue = queue;

    HRESULT result = g_Device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&g_Fence));
    for (auto& slot : g_Slots) {
        if (SUCCEEDED(result))
            result = g_Device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&slot.allocator));
    }
    if (SUCCEEDED(result))
        result = g_Device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_Slots[0].allocator, nullptr, IID_PPV_ARGS(&g_List));
    if (FAILED(result))
        return Fail("creating command objects", result);
    g_List->Close();

    D3D12_DESCRIPTOR_HEAP_DESC heap {};
    heap.NumDescriptors = 1;
    heap.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    result = g_Device->CreateDescriptorHeap(&heap, IID_PPV_ARGS(&g_RtvHeap));
    heap.Type = D3D12_DESCRIPTOR_HEAP_TYPE_DSV;
    if (SUCCEEDED(result))
        result = g_Device->CreateDescriptorHeap(&heap, IID_PPV_ARGS(&g_DsvHeap));
    heap.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    heap.NumDescriptors = kSrvCount;
    heap.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    if (SUCCEEDED(result))
        result = g_Device->CreateDescriptorHeap(&heap, IID_PPV_ARGS(&g_SrvHeap));
    if (FAILED(result))
        return Fail("creating descriptor heaps", result);
    g_SrvSize = g_Device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

    // Root signature: 24 float constants, one texture, a point and a linear sampler.
    D3D12_DESCRIPTOR_RANGE range {};
    range.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
    range.NumDescriptors = 1;
    D3D12_ROOT_PARAMETER parameters[2] {};
    parameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
    parameters[0].Constants.Num32BitValues = sizeof(Constants) / 4;
    parameters[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    parameters[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    parameters[1].DescriptorTable.NumDescriptorRanges = 1;
    parameters[1].DescriptorTable.pDescriptorRanges = &range;
    parameters[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
    D3D12_STATIC_SAMPLER_DESC samplers[2] {};
    for (int i = 0; i < 2; ++i) {
        samplers[i].Filter = i == 0 ? D3D12_FILTER_MIN_MAG_MIP_POINT : D3D12_FILTER_MIN_MAG_MIP_LINEAR;
        const auto address = i == 0 ? D3D12_TEXTURE_ADDRESS_MODE_WRAP : D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
        samplers[i].AddressU = samplers[i].AddressV = samplers[i].AddressW = address;
        samplers[i].ComparisonFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        samplers[i].MaxLOD = D3D12_FLOAT32_MAX;
        samplers[i].ShaderRegister = i;
        samplers[i].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
    }
    D3D12_ROOT_SIGNATURE_DESC signature {};
    signature.NumParameters = 2;
    signature.pParameters = parameters;
    signature.NumStaticSamplers = 2;
    signature.pStaticSamplers = samplers;
    signature.Flags = D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT;
    ID3DBlob* blob = nullptr;
    ID3DBlob* errors = nullptr;
    result = ::D3D12SerializeRootSignature(&signature, D3D_ROOT_SIGNATURE_VERSION_1, &blob, &errors);
    if (SUCCEEDED(result))
        result = g_Device->CreateRootSignature(0, blob->GetBufferPointer(), blob->GetBufferSize(), IID_PPV_ARGS(&g_RootSignature));
    if (blob)
        blob->Release();
    if (errors)
        errors->Release();
    if (FAILED(result))
        return Fail("creating the root signature", result);

    g_BlockVS = Compile("BlockVS", "vs_5_0");
    g_BlockPS = Compile("BlockPS", "ps_5_0");
    g_OverlayVS = Compile("OverlayVS", "vs_5_0");
    g_OverlayPS = Compile("OverlayPS", "ps_5_0");
    if (!g_BlockVS || !g_BlockPS || !g_OverlayVS || !g_OverlayPS)
        return false;
    HcLog("renderer: device objects ready");
    return true;
}

bool CreatePipelines(DXGI_FORMAT p_Format) {
    if (p_Format == g_PipelineFormat && g_OverlayPipeline)
        return true;
    Release(g_BlockPipeline);
    Release(g_BlendPipeline);
    Release(g_OverlayPipeline);

    static const D3D12_INPUT_ELEMENT_DESC layout[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA, 0 },
        { "COLOR", 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, 12, D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 16, D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA, 0 },
    };

    D3D12_GRAPHICS_PIPELINE_STATE_DESC description {};
    description.pRootSignature = g_RootSignature;
    description.SampleMask = UINT_MAX;
    description.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID;
    description.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
    description.RasterizerState.DepthClipEnable = TRUE;
    description.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
    description.NumRenderTargets = 1;
    description.RTVFormats[0] = p_Format;
    description.DSVFormat = DXGI_FORMAT_D32_FLOAT;
    description.SampleDesc.Count = 1;
    auto& target = description.BlendState.RenderTarget[0];
    target.RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_RED | D3D12_COLOR_WRITE_ENABLE_GREEN | D3D12_COLOR_WRITE_ENABLE_BLUE;
    target.SrcBlend = D3D12_BLEND_SRC_ALPHA;
    target.DestBlend = D3D12_BLEND_INV_SRC_ALPHA;
    target.BlendOp = D3D12_BLEND_OP_ADD;
    target.SrcBlendAlpha = D3D12_BLEND_ONE;
    target.DestBlendAlpha = D3D12_BLEND_ZERO;
    target.BlendOpAlpha = D3D12_BLEND_OP_ADD;

    // Opaque and cut-out blocks.
    description.VS = { g_BlockVS->GetBufferPointer(), g_BlockVS->GetBufferSize() };
    description.PS = { g_BlockPS->GetBufferPointer(), g_BlockPS->GetBufferSize() };
    description.InputLayout = { layout, static_cast<UINT>(std::size(layout)) };
    description.DepthStencilState.DepthEnable = TRUE;
    description.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL;
    description.DepthStencilState.DepthFunc = D3D12_COMPARISON_FUNC_LESS_EQUAL;
    HRESULT result = g_Device->CreateGraphicsPipelineState(&description, IID_PPV_ARGS(&g_BlockPipeline));

    // Translucent blocks (glass, water).
    target.BlendEnable = TRUE;
    description.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ZERO;
    if (SUCCEEDED(result))
        result = g_Device->CreateGraphicsPipelineState(&description, IID_PPV_ARGS(&g_BlendPipeline));

    // Minecraft's own frame over everything.
    target.SrcBlend = D3D12_BLEND_ONE;
    description.VS = { g_OverlayVS->GetBufferPointer(), g_OverlayVS->GetBufferSize() };
    description.PS = { g_OverlayPS->GetBufferPointer(), g_OverlayPS->GetBufferSize() };
    description.InputLayout = {};
    description.DepthStencilState.DepthEnable = FALSE;
    if (SUCCEEDED(result))
        result = g_Device->CreateGraphicsPipelineState(&description, IID_PPV_ARGS(&g_OverlayPipeline));
    if (FAILED(result))
        return Fail("creating pipelines", result);
    g_PipelineFormat = p_Format;
    HcLog("renderer: pipelines ready for back buffer format %d", static_cast<int>(p_Format));
    return true;
}

bool EnsureDepth(std::uint32_t p_Width, std::uint32_t p_Height) {
    if (g_Depth && g_DepthW == p_Width && g_DepthH == p_Height)
        return true;
    Discard(g_Depth);
    D3D12_HEAP_PROPERTIES heap {};
    heap.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC description {};
    description.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    description.Width = p_Width;
    description.Height = p_Height;
    description.DepthOrArraySize = 1;
    description.MipLevels = 1;
    description.Format = DXGI_FORMAT_D32_FLOAT;
    description.SampleDesc.Count = 1;
    description.Flags = D3D12_RESOURCE_FLAG_ALLOW_DEPTH_STENCIL;
    D3D12_CLEAR_VALUE clear {};
    clear.Format = DXGI_FORMAT_D32_FLOAT;
    clear.DepthStencil.Depth = 1.f;
    const HRESULT result = g_Device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &description,
        D3D12_RESOURCE_STATE_DEPTH_WRITE, &clear, IID_PPV_ARGS(&g_Depth));
    if (FAILED(result))
        return Fail("creating the depth buffer", result);
    g_Device->CreateDepthStencilView(g_Depth, nullptr, g_DsvHeap->GetCPUDescriptorHandleForHeapStart());
    g_DepthW = p_Width;
    g_DepthH = p_Height;
    return true;
}

// Minecraft's fixed face shading (left out of its vertex colours) and light level, baked into the colour.
Vertex Convert(const RenVertex& p_Source) {
    static constexpr float faceShade[8] = { 1.f, 0.5f, 1.f, 0.8f, 0.8f, 0.6f, 0.6f, 1.f };
    const float light = static_cast<float>(std::max(p_Source.light & 0xFF, (p_Source.light >> 8) & 0xFF)) / 15.f;
    const float shade = faceShade[(p_Source.flags >> 4) & 7] * (0.35f + 0.65f * std::min(light, 1.f));
    const auto scale = [&](std::uint32_t p_Channel) {
        return static_cast<std::uint32_t>(std::min(255.f, static_cast<float>(p_Channel) * shade));
    };
    Vertex vertex;
    vertex.x = p_Source.x;
    vertex.y = -p_Source.z;
    vertex.z = p_Source.y;
    vertex.color = scale(p_Source.color & 0xFF) | (scale((p_Source.color >> 8) & 0xFF) << 8) |
        (scale((p_Source.color >> 16) & 0xFF) << 16) | (p_Source.color & 0xFF000000u);
    vertex.u = p_Source.u;
    vertex.v = p_Source.v;
    return vertex;
}

void ConsumeScene(const std::uint8_t* p_Data, std::uint32_t p_Bytes) {
    const auto* scene = reinterpret_cast<const RenScene*>(p_Data);
    const std::uint64_t required = sizeof(RenScene) + std::uint64_t(scene->batchCount) * sizeof(RenBatch) +
        std::uint64_t(scene->vertexCount) * sizeof(RenVertex);
    if (required > p_Bytes || scene->vertexCount > 2000000 || scene->batchCount > 100000)
        return;
    const auto* batches = reinterpret_cast<const RenBatch*>(p_Data + sizeof(RenScene));
    const auto* vertices = reinterpret_cast<const RenVertex*>(batches + scene->batchCount);

    g_SceneOrigin[0] = scene->originX;
    g_SceneOrigin[1] = -scene->originZ;
    g_SceneOrigin[2] = scene->originY;
    g_SceneVertices.resize(scene->vertexCount);
    for (std::uint32_t i = 0; i < scene->vertexCount; ++i)
        g_SceneVertices[i] = Convert(vertices[i]);
    g_SceneBatches.clear();
    for (std::uint32_t i = 0; i < scene->batchCount; ++i) {
        const auto& batch = batches[i];
        if (batch.count == 0 || std::uint64_t(batch.first) + batch.count > scene->vertexCount)
            continue;
        g_SceneBatches.push_back({ batch.texture, batch.first, batch.count, (batch.flags & 1) != 0 });
    }
    if (g_SceneMessages++ == 0)
        HcLog("renderer: first entity scene from Minecraft (%u batches, %u vertices)", scene->batchCount, scene->vertexCount);
}

void ConsumeBody(const std::uint8_t* p_Data, std::uint32_t p_Bytes, bool p_Avatar) {
    auto& g_BodyVertices = p_Avatar ? ::g_AvatarVertices : ::g_BodyVertices;
    auto& g_BodyBatches = p_Avatar ? ::g_AvatarBatches : ::g_BodyBatches;
    const auto* body = reinterpret_cast<const RenAvatar*>(p_Data);
    const std::uint64_t required = sizeof(RenAvatar) + std::uint64_t(body->batchCount) * sizeof(RenBatch) +
        std::uint64_t(body->vertexCount) * sizeof(RenVertex);
    if (required > p_Bytes || body->vertexCount > 200000 || body->batchCount > 4096)
        return;
    const auto* batches = reinterpret_cast<const RenBatch*>(p_Data + sizeof(RenAvatar));
    const auto* vertices = reinterpret_cast<const RenVertex*>(batches + body->batchCount);
    const bool first = g_BodyVertices.empty() && body->vertexCount > 0;

    g_BodyVertices.resize(body->vertexCount);
    for (std::uint32_t i = 0; i < body->vertexCount; ++i) {
        Vertex vertex = Convert(vertices[i]);
        vertex.x = vertices[i].x;
        vertex.y = vertices[i].y;
        vertex.z = vertices[i].z;
        g_BodyVertices[i] = vertex;
    }
    g_BodyBatches.clear();
    for (std::uint32_t i = 0; i < body->batchCount; ++i) {
        const auto& batch = batches[i];
        if (batch.count == 0 || std::uint64_t(batch.first) + batch.count > body->vertexCount)
            continue;
        g_BodyBatches.push_back({ batch.texture, batch.first, batch.count, (batch.flags >> 8) & 0xF, (batch.flags & 1) != 0 });
    }
    if (first)
        HcLog("renderer: received the Minecraft player's %s (%u batches, %u vertices)", p_Avatar ? "third-person model" : "body",
            body->batchCount, body->vertexCount);
}

// Appends the player's body at V's feet, turned to face where Minecraft looks. Camera-relative.
void AppendBody(const Game::Camera& p_Camera, const Game::Vec3& p_Feet, float p_YawDegrees, bool p_Avatar) {
    // The third-person model arrives already posed and turned; the standing body is turned here.
    const auto& g_BodyVertices = p_Avatar ? ::g_AvatarVertices : ::g_BodyVertices;
    const float yaw = p_Avatar ? 0.f : p_YawDegrees * 3.14159265f / 180.f;
    const float c = std::cos(yaw), s = std::sin(yaw);
    // Feet relative to the camera, in Minecraft axes.
    const float baseX = p_Feet.x - p_Camera.position.x;
    const float baseY = p_Feet.z - p_Camera.position.z;
    const float baseZ = -(p_Feet.y - p_Camera.position.y);
    // A little behind the eyes, so looking down shows the chest and legs rather than the inside of the neck.
    const float back = p_Avatar ? 0.f : 0.35f;
    for (const auto& vertex : g_BodyVertices) {
        const float x = vertex.x * c - vertex.z * s + s * back;
        const float z = vertex.x * s + vertex.z * c - c * back;
        g_EntityVertices.push_back({ baseX + x, -(baseZ + z), baseY + vertex.y, vertex.color, vertex.u, vertex.v });
    }
}

// Dropped items, arrows and thrown things: Minecraft only says where they are; the host builds them.
// Positions are relative to the camera, in game axes.
void BuildWorldEntities(const Game::Camera& p_Camera) {
    g_EntityVertices.clear();
    const double cameraMc[3] = { p_Camera.position.x, p_Camera.position.z, -p_Camera.position.y };
    constexpr float degrees = 3.14159265f / 180.f;

    const auto push = [&](const float p_Mc[3], float p_U, float p_V, std::uint32_t p_Color) {
        g_EntityVertices.push_back({ p_Mc[0], -p_Mc[2], p_Mc[1], p_Color, p_U, p_V });
    };
    // p0 bottom-left, p1 bottom-right, p2 top-right, p3 top-left; rect is {u0, v0, u1, v1}.
    const auto quad = [&](const float p0[3], const float p1[3], const float p2[3], const float p3[3], const float p_Rect[4],
        std::uint32_t p_Color) {
        push(p0, p_Rect[0], p_Rect[3], p_Color);
        push(p1, p_Rect[2], p_Rect[3], p_Color);
        push(p2, p_Rect[2], p_Rect[1], p_Color);
        push(p0, p_Rect[0], p_Rect[3], p_Color);
        push(p2, p_Rect[2], p_Rect[1], p_Color);
        push(p3, p_Rect[0], p_Rect[1], p_Color);
    };

    for (const auto& entity : g_WorldEntities) {
        const float px = static_cast<float>(entity.x - cameraMc[0]);
        const float py = static_cast<float>(entity.y - cameraMc[1]);
        const float pz = static_cast<float>(entity.z - cameraMc[2]);
        constexpr std::uint32_t white = 0xFFFFFFFFu;

        if (entity.kind == kWeItem) {
            // A flat sprite turning about the vertical.
            const float spin = entity.yaw * degrees, half = entity.scale * 0.5f;
            const float rx = std::cos(spin) * half, rz = std::sin(spin) * half;
            const float p0[3] = { px - rx, py - half, pz - rz }, p1[3] = { px + rx, py - half, pz + rz };
            const float p2[3] = { px + rx, py + half, pz + rz }, p3[3] = { px - rx, py + half, pz - rz };
            quad(p0, p1, p2, p3, entity.uv[0], white);
        } else if (entity.kind == kWeBlock) {
            // A small cube spinning about its centre.
            const float spin = entity.yaw * degrees, half = entity.scale * 0.5f;
            const float c = std::cos(spin) * half, s = std::sin(spin) * half;
            // The four corners of the footprint, counter-clockwise.
            const float cx[4] = { -c + s, c + s, c - s, -c - s }, cz[4] = { -s - c, s - c, s + c, -s + c };
            for (int side = 0; side < 4; ++side) {
                const int next = (side + 1) & 3;
                const float p0[3] = { px + cx[side], py - half, pz + cz[side] }, p1[3] = { px + cx[next], py - half, pz + cz[next] };
                const float p2[3] = { px + cx[next], py + half, pz + cz[next] }, p3[3] = { px + cx[side], py + half, pz + cz[side] };
                const std::uint32_t shade = (side & 1) ? 0xFF999999u : 0xFFCCCCCCu;
                quad(p0, p1, p2, p3, entity.uv[0], shade);
            }
            const float t0[3] = { px + cx[0], py + half, pz + cz[0] }, t1[3] = { px + cx[1], py + half, pz + cz[1] };
            const float t2[3] = { px + cx[2], py + half, pz + cz[2] }, t3[3] = { px + cx[3], py + half, pz + cz[3] };
            quad(t0, t1, t2, t3, entity.uv[1], entity.tint ? (entity.tint | 0xFF000000u) : white);
            const float b0[3] = { px + cx[0], py - half, pz + cz[0] }, b1[3] = { px + cx[1], py - half, pz + cz[1] };
            const float b2[3] = { px + cx[2], py - half, pz + cz[2] }, b3[3] = { px + cx[3], py - half, pz + cz[3] };
            quad(b0, b1, b2, b3, entity.uv[2], 0xFF808080u);
        } else if (entity.kind == kWeArrow || entity.kind == kWeTrident) {
            // Two crossed strips along the flight direction (sin yaw, sin pitch, cos yaw).
            const float yaw = entity.yaw * degrees, pitch = entity.pitch * degrees;
            const float d[3] = { std::sin(yaw) * std::cos(pitch), std::sin(pitch), std::cos(yaw) * std::cos(pitch) };
            float a[3] = { d[2], 0.f, -d[0] }; // d x up
            float length = std::sqrt(a[0] * a[0] + a[2] * a[2]);
            if (length < 1e-4f) {
                a[0] = 1.f;
                a[2] = 0.f;
                length = 1.f;
            }
            a[0] /= length;
            a[2] /= length;
            const float b[3] = { d[1] * a[2] - d[2] * a[1], d[2] * a[0] - d[0] * a[2], d[0] * a[1] - d[1] * a[0] };
            constexpr float back = 0.7f, front = 0.3f, half = 0.16f;
            const float* sides[2] = { a, b };
            for (const float* side : sides) {
                const float p0[3] = { px - d[0] * back - side[0] * half, py - d[1] * back - side[1] * half, pz - d[2] * back - side[2] * half };
                const float p1[3] = { px + d[0] * front - side[0] * half, py + d[1] * front - side[1] * half, pz + d[2] * front - side[2] * half };
                const float p2[3] = { px + d[0] * front + side[0] * half, py + d[1] * front + side[1] * half, pz + d[2] * front + side[2] * half };
                const float p3[3] = { px - d[0] * back + side[0] * half, py - d[1] * back + side[1] * half, pz - d[2] * back + side[2] * half };
                quad(p0, p1, p2, p3, entity.uv[0], white);
            }
        }
    }
}

// A block mesh from Minecraft: positions relative to its 16-block section, converted to game axes.
void BuildSection(const SectionKey& p_Key, const RenVertex* p_Vertices, std::uint32_t p_Count) {
    auto& section = g_Sections[p_Key];
    Discard(section.buffer);
    section.opaque = section.translucent = 0;

    // Minecraft's fixed face shading (left out of its vertex colours): none, down, up, north, south, west, east.
    static constexpr float faceShade[8] = { 1.f, 0.5f, 1.f, 0.8f, 0.8f, 0.6f, 0.6f, 1.f };
    std::vector<Vertex> opaque, translucent;
    opaque.reserve(p_Count);
    for (std::uint32_t i = 0; i + 2 < p_Count; i += 3) {
        auto& list = (p_Vertices[i].flags & 2) ? translucent : opaque;
        for (int n = 0; n < 3; ++n) {
            const auto& source = p_Vertices[i + n];
            const float light = static_cast<float>(std::max(source.light & 0xFF, (source.light >> 8) & 0xFF)) / 15.f;
            const float shade = faceShade[(source.flags >> 4) & 7] * (0.35f + 0.65f * std::min(light, 1.f));
            const auto scale = [&](std::uint32_t p_Channel) {
                return static_cast<std::uint32_t>(std::min(255.f, static_cast<float>(p_Channel) * shade));
            };
            Vertex vertex;
            vertex.x = source.x;
            vertex.y = -source.z;
            vertex.z = source.y;
            vertex.color = scale(source.color & 0xFF) | (scale((source.color >> 8) & 0xFF) << 8) |
                (scale((source.color >> 16) & 0xFF) << 16) | 0xFF000000u;
            vertex.u = source.u;
            vertex.v = source.v;
            list.push_back(vertex);
        }
    }

    const std::size_t total = opaque.size() + translucent.size();
    if (total == 0) {
        g_Sections.erase(p_Key);
        return;
    }
    std::uint8_t* mapped = nullptr;
    section.buffer = CreateBuffer(total * sizeof(Vertex), &mapped);
    if (!section.buffer) {
        g_Sections.erase(p_Key);
        return;
    }
    std::memcpy(mapped, opaque.data(), opaque.size() * sizeof(Vertex));
    std::memcpy(mapped + opaque.size() * sizeof(Vertex), translucent.data(), translucent.size() * sizeof(Vertex));
    section.opaque = static_cast<std::uint32_t>(opaque.size());
    section.translucent = static_cast<std::uint32_t>(translucent.size());
    const auto [sx, sy, sz] = p_Key;
    section.origin[0] = sx * 16.0;
    section.origin[1] = -(sz * 16.0);
    section.origin[2] = sy * 16.0;
}

void ConsumeRenderMessage(std::uint32_t p_Type, const std::uint8_t* p_Data, std::uint32_t p_Bytes) {
    if (p_Type == kRenClearAll) {
        for (auto& [key, section] : g_Sections)
            Discard(section.buffer);
        g_Sections.clear();
        return;
    }
    if (p_Type == kRenAtlas && p_Bytes >= sizeof(RenAtlas)) {
        const auto* atlas = reinterpret_cast<const RenAtlas*>(p_Data);
        const std::uint64_t bytes = std::uint64_t(atlas->width) * atlas->height * 4;
        if (atlas->width == 0 || atlas->height == 0 || atlas->width > 16384 || atlas->height > 16384 ||
            sizeof(RenAtlas) + bytes > p_Bytes)
            return;
        g_AtlasW = atlas->width;
        g_AtlasH = atlas->height;
        g_Atlas.assign(p_Data + sizeof(RenAtlas), p_Data + sizeof(RenAtlas) + bytes);
        g_AtlasDirty = true;
        HcLog("renderer: received Minecraft's %ux%u block atlas", g_AtlasW, g_AtlasH);
        return;
    }
    if (p_Type == kRenAtlasRegion && p_Bytes >= 16) {
        std::uint32_t rect[4];
        std::memcpy(rect, p_Data, sizeof(rect));
        const std::uint64_t bytes = std::uint64_t(rect[2]) * rect[3] * 4;
        if (rect[2] == 0 || rect[3] == 0 || rect[0] + rect[2] > g_AtlasW || rect[1] + rect[3] > g_AtlasH || 16 + bytes > p_Bytes)
            return;
        if (g_PendingRegions.size() < 512) {
            AtlasRegion region { rect[0], rect[1], rect[2], rect[3], {} };
            region.pixels.assign(p_Data + 16, p_Data + 16 + bytes);
            g_PendingRegions.push_back(std::move(region));
        }
        return;
    }
    if (p_Type == kRenLights && p_Bytes >= 16) {
        std::int32_t header[4];
        std::memcpy(header, p_Data, sizeof(header));
        const std::uint32_t count = static_cast<std::uint32_t>(header[3]);
        if (16 + std::uint64_t(count) * 8 > p_Bytes)
            return;
        std::vector<Renderer::Hazard> hazards;
        for (std::uint32_t i = 0; i < count; ++i) {
            const std::uint8_t* light = p_Data + 16 + std::size_t(i) * 8;
            std::uint32_t color;
            std::memcpy(&color, light + 4, sizeof(color));
            const std::uint8_t kind = static_cast<std::uint8_t>((color >> 28) & 0xF);
            if (kind != 0)
                hazards.push_back({ header[0] * 16 + light[0], header[1] * 16 + light[1], header[2] * 16 + light[2], kind });
        }
        std::scoped_lock lock(g_HazardMutex);
        const SectionKey key = std::make_tuple(header[0], header[1], header[2]);
        if (hazards.empty())
            g_Hazards.erase(key);
        else
            g_Hazards[key] = std::move(hazards);
        return;
    }
    if (p_Type == kRenTexture && p_Bytes >= sizeof(RenTexture)) {
        const auto* texture = reinterpret_cast<const RenTexture*>(p_Data);
        const std::uint64_t bytes = std::uint64_t(texture->width) * texture->height * 4;
        if (texture->width == 0 || texture->height == 0 || texture->width > 8192 || texture->height > 8192 ||
            sizeof(RenTexture) + bytes > p_Bytes)
            return;
        PendingTexture pending { texture->id, texture->width, texture->height, {} };
        pending.pixels.assign(p_Data + sizeof(RenTexture), p_Data + sizeof(RenTexture) + bytes);
        g_PendingTextures.push_back(std::move(pending));
        return;
    }
    if ((p_Type == kRenRagdoll || p_Type == kRenAvatarMessage) && p_Bytes >= sizeof(RenAvatar)) {
        ConsumeBody(p_Data, p_Bytes, p_Type == kRenAvatarMessage);
        return;
    }
    if (p_Type == kRenScene && p_Bytes >= sizeof(RenScene)) {
        ConsumeScene(p_Data, p_Bytes);
        return;
    }
    if (p_Type != kRenSection || p_Bytes < sizeof(RenSection))
        return;
    const auto* header = reinterpret_cast<const RenSection*>(p_Data);
    const SectionKey key = std::make_tuple(header->sx, header->sy, header->sz);
    const auto required = sizeof(*header) + std::uint64_t(header->vertexCount) * sizeof(RenVertex);
    if (header->vertexCount == 0 || required > p_Bytes || header->vertexCount > 600000) {
        if (const auto found = g_Sections.find(key); found != g_Sections.end()) {
            Discard(found->second.buffer);
            g_Sections.erase(found);
        }
        return;
    }
    BuildSection(key, reinterpret_cast<const RenVertex*>(p_Data + sizeof(*header)), header->vertexCount);
}

Slot* FreeSlot() {
    const std::uint64_t completed = g_Fence->GetCompletedValue();
    for (auto& slot : g_Slots) {
        if (slot.fenceValue <= completed)
            return &slot;
    }
    return nullptr;
}

void RenderFrame(IDXGISwapChain* p_SwapChain) {
    HitCraftLink* link = g_Link.load(std::memory_order_acquire);
    if (g_Failed || !link || !link->Valid())
        return;

    DXGI_SWAP_CHAIN_DESC description {};
    if (FAILED(p_SwapChain->GetDesc(&description)) || description.BufferDesc.Width == 0)
        return;
    g_Width.store(description.BufferDesc.Width, std::memory_order_relaxed);
    g_Height.store(description.BufferDesc.Height, std::memory_order_relaxed);
    g_Window.store(description.OutputWindow, std::memory_order_relaxed);

    if (!link->MinecraftAlive()) {
        g_HaveOverlay = false;
        return;
    }
    if (!g_Device && !CreateDeviceObjects(p_SwapChain))
        return;

    ++g_Frame;
    for (auto it = g_Garbage.begin(); it != g_Garbage.end();) {
        if (g_Frame - it->second > 8) {
            it->first->Release();
            it = g_Garbage.erase(it);
        } else {
            ++it;
        }
    }

    link->DrainRender([](std::uint32_t p_Type, const std::uint8_t* p_Data, std::uint32_t p_Bytes) {
        ConsumeRenderMessage(p_Type, p_Data, p_Bytes);
    }, 8ull << 20);
    g_SectionCount.store(g_Sections.size(), std::memory_order_relaxed);

    // Minecraft's messages are taken even while nothing is drawn (the main menu, a loading screen):
    // it starts before a save is loaded now, and would stall against a full queue otherwise.
    if (!g_Enabled.load(std::memory_order_relaxed)) {
        g_HaveOverlay = false;
        if (g_PendingRegions.size() > 256)
            g_PendingRegions.clear();
        return;
    }
    if (!CreatePipelines(description.BufferDesc.Format) ||
        !EnsureDepth(description.BufferDesc.Width, description.BufferDesc.Height))
        return;

    Slot* slot = FreeSlot();
    if (!slot)
        return;
    IDXGISwapChain3* swapChain3 = nullptr;
    if (FAILED(p_SwapChain->QueryInterface(IID_PPV_ARGS(&swapChain3))))
        return;
    ID3D12Resource* backBuffer = nullptr;
    const HRESULT got = swapChain3->GetBuffer(swapChain3->GetCurrentBackBufferIndex(), IID_PPV_ARGS(&backBuffer));
    swapChain3->Release();
    if (FAILED(got))
        return;
    if (FAILED(slot->allocator->Reset()) || FAILED(g_List->Reset(slot->allocator, nullptr))) {
        backBuffer->Release();
        return;
    }

    // --- uploads -----------------------------------------------------------------------------
    if (g_AtlasDirty && !g_Atlas.empty()) {
        g_AtlasDirty = false;
        Discard(g_AtlasTexture);
        Discard(g_AtlasUpload);
        const std::uint32_t rowPitch = (g_AtlasW * 4 + 255) & ~255u;
        std::uint8_t* mapped = nullptr;
        g_AtlasUpload = CreateBuffer(std::uint64_t(rowPitch) * g_AtlasH, &mapped);
        g_AtlasTexture = g_AtlasUpload ? CreateTexture(g_AtlasW, g_AtlasH, 0) : nullptr;
        if (g_AtlasTexture) {
            for (std::uint32_t y = 0; y < g_AtlasH; ++y)
                std::memcpy(mapped + std::size_t(y) * rowPitch, g_Atlas.data() + std::size_t(y) * g_AtlasW * 4, std::size_t(g_AtlasW) * 4);
            CopyToTexture(g_AtlasTexture, g_AtlasUpload, g_AtlasW, g_AtlasH, rowPitch);
            HcLog("renderer: block atlas texture ready");
        }
    }

    if (!g_PendingRegions.empty() && g_AtlasTexture) {
        // Each rectangle gets its own 512-aligned place in this frame's upload buffer.
        std::uint64_t total = 0;
        for (const auto& region : g_PendingRegions)
            total += ((std::uint64_t((region.width * 4 + 255) & ~255u) * region.height) + 511) & ~511ull;
        if (slot->regionsCapacity < total) {
            Discard(slot->regions);
            slot->regions = CreateBuffer(total * 2, &slot->regionsMapped);
            slot->regionsCapacity = slot->regions ? total * 2 : 0;
        }
        if (slot->regions) {
            Transition(g_AtlasTexture, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
            std::uint64_t offset = 0;
            for (const auto& region : g_PendingRegions) {
                const std::uint32_t rowPitch = (region.width * 4 + 255) & ~255u;
                for (std::uint32_t y = 0; y < region.height; ++y)
                    std::memcpy(slot->regionsMapped + offset + std::size_t(y) * rowPitch,
                        region.pixels.data() + std::size_t(y) * region.width * 4, std::size_t(region.width) * 4);
                D3D12_TEXTURE_COPY_LOCATION destination {};
                destination.pResource = g_AtlasTexture;
                destination.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
                D3D12_TEXTURE_COPY_LOCATION source {};
                source.pResource = slot->regions;
                source.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
                source.PlacedFootprint.Offset = offset;
                source.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                source.PlacedFootprint.Footprint.Width = region.width;
                source.PlacedFootprint.Footprint.Height = region.height;
                source.PlacedFootprint.Footprint.Depth = 1;
                source.PlacedFootprint.Footprint.RowPitch = rowPitch;
                g_List->CopyTextureRegion(&destination, region.x, region.y, 0, &source, nullptr);
                offset += ((std::uint64_t(rowPitch) * region.height) + 511) & ~511ull;
            }
            Transition(g_AtlasTexture, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
        }
    }
    g_PendingRegions.clear();

    for (auto& pending : g_PendingTextures) {
        auto& entry = g_EntityTextures[pending.id];
        if (entry.srv == 0) {
            if (g_NextEntitySrv >= kSrvCount)
                continue;
            entry.srv = g_NextEntitySrv++;
        }
        Discard(entry.texture);
        const std::uint32_t rowPitch = (pending.width * 4 + 255) & ~255u;
        std::uint8_t* mapped = nullptr;
        ID3D12Resource* upload = CreateBuffer(std::uint64_t(rowPitch) * pending.height, &mapped);
        entry.texture = upload ? CreateTexture(pending.width, pending.height, entry.srv) : nullptr;
        if (entry.texture) {
            for (std::uint32_t y = 0; y < pending.height; ++y)
                std::memcpy(mapped + std::size_t(y) * rowPitch, pending.pixels.data() + std::size_t(y) * pending.width * 4, std::size_t(pending.width) * 4);
            CopyToTexture(entry.texture, upload, pending.width, pending.height, rowPitch);
        }
        Discard(upload); // released once this frame has run
    }
    g_PendingTextures.clear();

    if (!g_CursorTexture) {
        // A plain arrow for Minecraft's screens: its own window is hidden, so it has no cursor.
        const std::uint32_t rowPitch = 256;
        std::uint8_t* mapped = nullptr;
        g_CursorUpload = CreateBuffer(std::uint64_t(rowPitch) * kCursorSize, &mapped);
        g_CursorTexture = g_CursorUpload ? CreateTexture(kCursorSize, kCursorSize, 2) : nullptr;
        if (g_CursorTexture) {
            const auto inside = [](int p_X, int p_Y) {
                return p_X >= 0 && p_Y >= 0 && p_Y < 15 && p_X <= p_Y * 0.7f && p_X <= (15 - p_Y) * 1.6f;
            };
            for (int y = 0; y < static_cast<int>(kCursorSize); ++y) {
                auto* row = reinterpret_cast<std::uint32_t*>(mapped + std::size_t(y) * rowPitch);
                for (int x = 0; x < static_cast<int>(kCursorSize); ++x) {
                    const bool edge = inside(x, y) && !(inside(x - 1, y) && inside(x + 1, y) && inside(x, y - 1) && inside(x, y + 1));
                    row[x] = !inside(x, y) ? 0u : edge ? 0xFF000000u : 0xFFFFFFFFu;
                }
            }
            CopyToTexture(g_CursorTexture, g_CursorUpload, kCursorSize, kCursorSize, rowPitch);
        }
    }

    if (link->OverlayPending()) {
        const std::uint8_t* pixels = nullptr;
        std::uint32_t width = 0, height = 0;
        bool bottomUp = false;
        if (link->AcquireOverlay(pixels, width, height, bottomUp)) {
            if (!g_OverlayTexture || g_OverlayW != width || g_OverlayH != height) {
                Discard(g_OverlayTexture);
                g_OverlayTexture = CreateTexture(width, height, 1);
                g_OverlayW = width;
                g_OverlayH = height;
                HcLog("renderer: Minecraft frame is %ux%u (%s)", width, height, bottomUp ? "bottom-up" : "top-down");
            }
            const std::uint32_t rowPitch = (width * 4 + 255) & ~255u;
            const std::uint64_t bytes = std::uint64_t(rowPitch) * height;
            if (slot->capacity < bytes) {
                Discard(slot->upload);
                slot->upload = CreateBuffer(bytes, &slot->mapped);
                slot->capacity = slot->upload ? bytes : 0;
            }
            if (g_OverlayTexture && slot->upload) {
                if (rowPitch == width * 4) {
                    std::memcpy(slot->mapped, pixels, bytes);
                } else {
                    for (std::uint32_t y = 0; y < height; ++y)
                        std::memcpy(slot->mapped + std::size_t(y) * rowPitch, pixels + std::size_t(y) * width * 4, std::size_t(width) * 4);
                }
                CopyToTexture(g_OverlayTexture, slot->upload, width, height, rowPitch);
                g_OverlayBottomUp = bottomUp;
                g_HaveOverlay = true;
                g_OverlayFrames.fetch_add(1, std::memory_order_relaxed);
            }
        }
    }

    // --- draw --------------------------------------------------------------------------------
    const float width = static_cast<float>(description.BufferDesc.Width), height = static_cast<float>(description.BufferDesc.Height);
    const auto rtv = g_RtvHeap->GetCPUDescriptorHandleForHeapStart();
    const auto dsv = g_DsvHeap->GetCPUDescriptorHandleForHeapStart();
    g_Device->CreateRenderTargetView(backBuffer, nullptr, rtv);
    Transition(backBuffer, D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_RENDER_TARGET);
    g_List->OMSetRenderTargets(1, &rtv, FALSE, &dsv);
    g_List->ClearDepthStencilView(dsv, D3D12_CLEAR_FLAG_DEPTH, 1.f, 0, 0, nullptr);
    const D3D12_VIEWPORT viewport { 0.f, 0.f, width, height, 0.f, 1.f };
    const D3D12_RECT scissor { 0, 0, static_cast<LONG>(description.BufferDesc.Width), static_cast<LONG>(description.BufferDesc.Height) };
    g_List->RSSetViewports(1, &viewport);
    g_List->RSSetScissorRects(1, &scissor);
    g_List->SetGraphicsRootSignature(g_RootSignature);
    g_List->SetDescriptorHeaps(1, &g_SrvHeap);
    g_List->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    Game::Camera camera;
    Game::Vec3 playerFeet;
    float playerYaw;
    bool cameraValid, playerVisible, playerThirdPerson;
    {
        std::scoped_lock lock(g_CameraMutex);
        camera = g_Camera;
        cameraValid = g_CameraValid;
        playerFeet = g_PlayerFeet;
        playerYaw = g_PlayerYaw;
        playerVisible = g_PlayerVisible;
        playerThirdPerson = g_PlayerThirdPerson;
    }

    Constants constants {};
    auto srv = g_SrvHeap->GetGPUDescriptorHandleForHeapStart();
    if (cameraValid && g_AtlasTexture) {
        constexpr float nearPlane = 0.05f, farPlane = 600.f;
        const float scaleX = camera.scaleX > 0.f ? camera.scaleX : camera.scaleY * height / width;
        const float depthScale = farPlane / (farPlane - nearPlane);
        const float rows[4][4] = {
            { camera.right.x * scaleX, camera.right.y * scaleX, camera.right.z * scaleX, 0.f },
            { camera.up.x * camera.scaleY, camera.up.y * camera.scaleY, camera.up.z * camera.scaleY, 0.f },
            { camera.forward.x * depthScale, camera.forward.y * depthScale, camera.forward.z * depthScale, -nearPlane * depthScale },
            { camera.forward.x, camera.forward.y, camera.forward.z, 0.f },
        };
        std::memcpy(constants.row0, rows, sizeof(rows));
        g_List->SetGraphicsRootDescriptorTable(1, srv);

        for (int pass = 0; pass < 2; ++pass) {
            g_List->SetPipelineState(pass == 0 ? g_BlockPipeline : g_BlendPipeline);
            constants.misc[0] = pass == 0 ? 0.4f : 0.01f;
            for (const auto& [key, section] : g_Sections) {
                const std::uint32_t count = pass == 0 ? section.opaque : section.translucent;
                if (!section.buffer || count == 0)
                    continue;
                // Camera-relative, in doubles: Night City is kilometres across.
                constants.offset[0] = static_cast<float>(section.origin[0] - camera.position.x);
                constants.offset[1] = static_cast<float>(section.origin[1] - camera.position.y);
                constants.offset[2] = static_cast<float>(section.origin[2] - camera.position.z);
                g_List->SetGraphicsRoot32BitConstants(0, sizeof(Constants) / 4, &constants, 0);
                D3D12_VERTEX_BUFFER_VIEW view {};
                view.BufferLocation = section.buffer->GetGPUVirtualAddress() + (pass == 0 ? 0 : std::uint64_t(section.opaque) * sizeof(Vertex));
                view.SizeInBytes = count * sizeof(Vertex);
                view.StrideInBytes = sizeof(Vertex);
                g_List->IASetVertexBuffers(0, 1, &view);
                g_List->DrawInstanced(count, 1, 0, 0);
            }
        }

        // Entities and particles (this frame's mesh from Minecraft), then the things we build ourselves.
        if (!link->ReadWorldEntities(g_WorldEntities))
            g_WorldEntities.clear();
        BuildWorldEntities(camera);
        const std::size_t builtEntities = g_EntityVertices.size();
        // The animated model only in Minecraft's third-person views; in first person, the standing body.
        const bool avatar = playerThirdPerson && !g_AvatarBatches.empty();
        const bool drawBody = playerVisible && (avatar || !g_BodyVertices.empty());
        if (drawBody)
            AppendBody(camera, playerFeet, playerYaw, avatar);
        const std::uint64_t sceneBytes = g_SceneVertices.size() * sizeof(Vertex);
        const std::uint64_t entityBytes = g_EntityVertices.size() * sizeof(Vertex);
        if (sceneBytes + entityBytes > 0) {
            if (slot->dynamicCapacity < sceneBytes + entityBytes) {
                Discard(slot->dynamic);
                const std::uint64_t capacity = (sceneBytes + entityBytes) * 2;
                slot->dynamic = CreateBuffer(capacity, &slot->dynamicMapped);
                slot->dynamicCapacity = slot->dynamic ? capacity : 0;
            }
            if (slot->dynamic) {
                std::memcpy(slot->dynamicMapped, g_SceneVertices.data(), sceneBytes);
                std::memcpy(slot->dynamicMapped + sceneBytes, g_EntityVertices.data(), entityBytes);
                D3D12_VERTEX_BUFFER_VIEW view {};
                view.BufferLocation = slot->dynamic->GetGPUVirtualAddress();
                view.SizeInBytes = static_cast<UINT>(sceneBytes + entityBytes);
                view.StrideInBytes = sizeof(Vertex);
                g_List->IASetVertexBuffers(0, 1, &view);

                constants.offset[0] = static_cast<float>(g_SceneOrigin[0] - camera.position.x);
                constants.offset[1] = static_cast<float>(g_SceneOrigin[1] - camera.position.y);
                constants.offset[2] = static_cast<float>(g_SceneOrigin[2] - camera.position.z);
                for (int pass = 0; pass < 2; ++pass) {
                    g_List->SetPipelineState(pass == 0 ? g_BlockPipeline : g_BlendPipeline);
                    constants.misc[0] = pass == 0 ? 0.1f : 0.01f;
                    g_List->SetGraphicsRoot32BitConstants(0, sizeof(Constants) / 4, &constants, 0);
                    for (const auto& batch : g_SceneBatches) {
                        if (batch.translucent != (pass == 1))
                            continue;
                        auto texture = g_SrvHeap->GetGPUDescriptorHandleForHeapStart();
                        if (batch.texture != 0) {
                            const auto found = g_EntityTextures.find(batch.texture);
                            if (found == g_EntityTextures.end() || !found->second.texture)
                                continue;
                            texture.ptr += static_cast<UINT64>(found->second.srv) * g_SrvSize;
                        }
                        g_List->SetGraphicsRootDescriptorTable(1, texture);
                        g_List->DrawInstanced(batch.count, 1, batch.first, 0);
                    }
                }

                if (!g_EntityVertices.empty()) {
                    constants.offset[0] = constants.offset[1] = constants.offset[2] = 0.f;
                    constants.misc[0] = 0.4f;
                    g_List->SetPipelineState(g_BlockPipeline);
                    g_List->SetGraphicsRootDescriptorTable(1, g_SrvHeap->GetGPUDescriptorHandleForHeapStart());
                    g_List->SetGraphicsRoot32BitConstants(0, sizeof(Constants) / 4, &constants, 0);
                    if (builtEntities > 0)
                        g_List->DrawInstanced(static_cast<UINT>(builtEntities), 1, static_cast<UINT>(g_SceneVertices.size()), 0);

                    if (drawBody) {
                        // Everything but the head: the camera sits inside it.
                        const UINT base = static_cast<UINT>(g_SceneVertices.size() + builtEntities);
                        constants.misc[0] = 0.1f;
                        g_List->SetGraphicsRoot32BitConstants(0, sizeof(Constants) / 4, &constants, 0);
                        for (const auto& batch : avatar ? g_AvatarBatches : g_BodyBatches) {
                            // First person: torso and legs only. The head would be around the camera and
                            // the arms fill the bottom of the screen (Minecraft draws its own hand).
                            if (!avatar && batch.part != kPartBody && batch.part != kPartRightLeg && batch.part != kPartLeftLeg)
                                continue;
                            auto texture = g_SrvHeap->GetGPUDescriptorHandleForHeapStart();
                            if (batch.texture != 0) {
                                const auto found = g_EntityTextures.find(batch.texture);
                                if (found == g_EntityTextures.end() || !found->second.texture)
                                    continue;
                                texture.ptr += static_cast<UINT64>(found->second.srv) * g_SrvSize;
                            }
                            g_List->SetGraphicsRootDescriptorTable(1, texture);
                            g_List->DrawInstanced(batch.count, 1, base + batch.first, 0);
                        }
                    }
                }
            }
        }
    }
    if (g_HaveOverlay && g_OverlayTexture) {
        constants.misc[1] = g_OverlayBottomUp ? 1.f : 0.f;
        srv.ptr += g_SrvSize;
        g_List->SetPipelineState(g_OverlayPipeline);
        g_List->SetGraphicsRootDescriptorTable(1, srv);
        g_List->SetGraphicsRoot32BitConstants(0, sizeof(Constants) / 4, &constants, 0);
        g_List->DrawInstanced(3, 1, 0, 0);

        if (g_CursorTexture && g_CursorVisible.load(std::memory_order_relaxed) && g_OverlayW > 0 && g_OverlayH > 0) {
            // The same full-screen triangle, squeezed into a small viewport at the cursor.
            const float size = std::max(16.f, height / 45.f);
            const D3D12_VIEWPORT cursorViewport {
                g_CursorX.load(std::memory_order_relaxed) * width / static_cast<float>(g_OverlayW),
                g_CursorY.load(std::memory_order_relaxed) * height / static_cast<float>(g_OverlayH), size, size, 0.f, 1.f };
            constants.misc[1] = 0.f;
            srv.ptr += g_SrvSize;
            g_List->RSSetViewports(1, &cursorViewport);
            g_List->SetGraphicsRootDescriptorTable(1, srv);
            g_List->SetGraphicsRoot32BitConstants(0, sizeof(Constants) / 4, &constants, 0);
            g_List->DrawInstanced(3, 1, 0, 0);
        }
    }

    Transition(backBuffer, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_PRESENT);
    backBuffer->Release();
    if (FAILED(g_List->Close()))
        return;
    ID3D12CommandList* lists[] = { g_List };
    g_Queue->ExecuteCommandLists(1, lists);
    g_Queue->Signal(g_Fence, ++g_FenceValue);
    slot->fenceValue = g_FenceValue;
}

void STDMETHODCALLTYPE ExecuteDetour(ID3D12CommandQueue* p_Queue, UINT p_Count, ID3D12CommandList* const* p_Lists) {
    if (!g_CapturedQueue.load(std::memory_order_relaxed) && p_Queue->GetDesc().Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
        p_Queue->AddRef();
        ID3D12CommandQueue* expected = nullptr;
        if (!g_CapturedQueue.compare_exchange_strong(expected, p_Queue))
            p_Queue->Release();
    }
    g_OriginalExecute(p_Queue, p_Count, p_Lists);
}

HRESULT STDMETHODCALLTYPE PresentDetour(IDXGISwapChain* p_SwapChain, UINT p_SyncInterval, UINT p_Flags) {
    g_Presents.fetch_add(1, std::memory_order_relaxed);
    if (!(p_Flags & DXGI_PRESENT_TEST))
        RenderFrame(p_SwapChain);
    return g_OriginalPresent(p_SwapChain, p_SyncInterval, p_Flags);
}

HRESULT STDMETHODCALLTYPE Present1Detour(IDXGISwapChain1* p_SwapChain, UINT p_SyncInterval, UINT p_Flags,
    const DXGI_PRESENT_PARAMETERS* p_Parameters) {
    g_Presents.fetch_add(1, std::memory_order_relaxed);
    if (!(p_Flags & DXGI_PRESENT_TEST))
        RenderFrame(p_SwapChain);
    return g_OriginalPresent1(p_SwapChain, p_SyncInterval, p_Flags, p_Parameters);
}

bool PatchSlot(void** p_Table, int p_Index, void* p_Detour, void** p_Original) {
    DWORD protection = 0;
    if (!::VirtualProtect(&p_Table[p_Index], sizeof(void*), PAGE_EXECUTE_READWRITE, &protection))
        return false;
    *p_Original = p_Table[p_Index];
    p_Table[p_Index] = p_Detour;
    ::VirtualProtect(&p_Table[p_Index], sizeof(void*), protection, &protection);
    return true;
}
}

bool Renderer::Install() {
    if (g_Installed)
        return true;
    if (!::GetModuleHandleW(L"d3d12.dll") || !::GetModuleHandleW(L"dxgi.dll"))
        return false; // not loaded (yet): the game may be running on Vulkan

    // The swap chain and command queue classes keep one table of functions each, shared by every
    // object of the class: make throw-away objects of our own just to find those tables.
    WNDCLASSEXW windowClass {};
    windowClass.cbSize = sizeof(windowClass);
    windowClass.lpfnWndProc = ::DefWindowProcW;
    windowClass.hInstance = ::GetModuleHandleW(nullptr);
    windowClass.lpszClassName = L"RedCraftProbe";
    ::RegisterClassExW(&windowClass);
    const HWND window = ::CreateWindowExW(0, windowClass.lpszClassName, L"", WS_OVERLAPPED, 0, 0, 64, 64, nullptr, nullptr,
        windowClass.hInstance, nullptr);

    ID3D12Device* device = nullptr;
    ID3D12CommandQueue* queue = nullptr;
    IDXGIFactory4* factory = nullptr;
    IDXGISwapChain1* swapChain = nullptr;
    HRESULT result = window ? ::D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_11_0, IID_PPV_ARGS(&device)) : E_FAIL;
    if (SUCCEEDED(result)) {
        D3D12_COMMAND_QUEUE_DESC description {};
        description.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        result = device->CreateCommandQueue(&description, IID_PPV_ARGS(&queue));
    }
    if (SUCCEEDED(result))
        result = ::CreateDXGIFactory1(IID_PPV_ARGS(&factory));
    if (SUCCEEDED(result)) {
        DXGI_SWAP_CHAIN_DESC1 description {};
        description.Width = 64;
        description.Height = 64;
        description.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        description.SampleDesc.Count = 1;
        description.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        description.BufferCount = 2;
        description.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
        result = factory->CreateSwapChainForHwnd(queue, window, &description, nullptr, nullptr, &swapChain);
    }

    bool present = false, present1 = false, execute = false;
    if (SUCCEEDED(result)) {
        void** swapTable = *reinterpret_cast<void***>(swapChain);
        void** queueTable = *reinterpret_cast<void***>(queue);
        execute = PatchSlot(queueTable, 10, &ExecuteDetour, reinterpret_cast<void**>(&g_OriginalExecute));
        present = PatchSlot(swapTable, 8, &PresentDetour, reinterpret_cast<void**>(&g_OriginalPresent));
        present1 = PatchSlot(swapTable, 22, &Present1Detour, reinterpret_cast<void**>(&g_OriginalPresent1));
    }
    if (swapChain)
        swapChain->Release();
    if (factory)
        factory->Release();
    if (queue)
        queue->Release();
    if (device)
        device->Release();
    if (window)
        ::DestroyWindow(window);
    ::UnregisterClassW(windowClass.lpszClassName, windowClass.hInstance);

    g_Installed = true; // one attempt: a second would patch the tables twice
    HcLog("renderer: DirectX 12 hooks: present %s, present1 %s, command queue %s (probe 0x%08X)", present ? "installed" : "FAILED",
        present1 ? "installed" : "FAILED", execute ? "installed" : "FAILED", static_cast<unsigned>(result));
    return true;
}

std::uint64_t Renderer::Presents() {
    return g_Presents.load(std::memory_order_relaxed);
}
void Renderer::SetLink(HitCraftLink* p_Link) {
    g_Link.store(p_Link, std::memory_order_release);
}

void Renderer::SetCamera(const Game::Camera& p_Camera, bool p_Valid) {
    std::scoped_lock lock(g_CameraMutex);
    g_Camera = p_Camera;
    g_CameraValid = p_Valid;
}

void Renderer::SetPlayer(const Game::Vec3& p_Feet, float p_MinecraftYaw, bool p_Visible, bool p_ThirdPerson) {
    std::scoped_lock lock(g_CameraMutex);
    g_PlayerFeet = p_Feet;
    g_PlayerYaw = p_MinecraftYaw;
    g_PlayerVisible = p_Visible;
    g_PlayerThirdPerson = p_ThirdPerson;
}

void Renderer::SetEnabled(bool p_Enabled) {
    g_Enabled.store(p_Enabled, std::memory_order_relaxed);
}

void Renderer::SetCursor(bool p_Visible, float p_X, float p_Y) {
    g_CursorVisible.store(p_Visible, std::memory_order_relaxed);
    g_CursorX.store(p_X, std::memory_order_relaxed);
    g_CursorY.store(p_Y, std::memory_order_relaxed);
}

void Renderer::CopyHazards(std::vector<Hazard>& p_Out) {
    p_Out.clear();
    std::scoped_lock lock(g_HazardMutex);
    for (const auto& [key, hazards] : g_Hazards)
        p_Out.insert(p_Out.end(), hazards.begin(), hazards.end());
}

std::uint32_t Renderer::Width() { return g_Width.load(std::memory_order_relaxed); }
std::uint32_t Renderer::Height() { return g_Height.load(std::memory_order_relaxed); }
HWND Renderer::Window() { return g_Window.load(std::memory_order_relaxed); }
std::uint64_t Renderer::OverlayFrames() { return g_OverlayFrames.load(std::memory_order_relaxed); }
std::size_t Renderer::Sections() { return g_SectionCount.load(std::memory_order_relaxed); }
